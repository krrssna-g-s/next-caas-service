import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {assertPageRegistry} from '../lib/published-registry';
test('published BFF and frontend registries match',()=>{
 const read=(p:string)=>JSON.parse(readFileSync(new URL(p,import.meta.url),'utf8'));
 assert.deepEqual(read('../public/registry.json'),read('../../wireless-bff/data/registry.json'));
 assert.throws(()=>assertPageRegistry('catalog',[{id:'a',component:'arbitraryScript',props:{}}]));
 assert.throws(()=>assertPageRegistry('catalog',[{id:'a',component:'messageBanner',props:{title:12}}]));
 assert.doesNotThrow(()=>assertPageRegistry('checkout',[{id:'a',component:'messageBanner',props:{title:'Hello',body:'Business copy',tone:'info'}},{id:'b',component:'messageBanner',props:{title:'Second',body:'Different copy',tone:'success'}}]));
 assert.doesNotThrow(()=>assertPageRegistry('checkout',[{id:'a',component:'phoneCatalog',props:{}}]));
});
