import type {NextConfig} from 'next';
const config:NextConfig={reactCompiler:true,cacheComponents:true,partialPrefetching:true,experimental:{serverComponentsHmrCache:false}};
export default config;
