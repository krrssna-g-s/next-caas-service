# Signal wireless — runtime BFF composition

The application now contains only the wireless journey. `/` redirects to `/wireless`; the previous generic landing, cart, payment and streaming demos have been removed. The wireless cart and checkout remain.

## Start both applications

Use Node.js 22.13+ and npm. Keep `template-lab` and `wireless-bff` as sibling directories.

Terminal 1:

```sh
cd ../wireless-bff
npm ci
npm run dev
```

Terminal 2, from this frontend directory:

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:3000/wireless. The composer is http://127.0.0.1:4000/composer; enter `local-composer-demo` and Load. Optional frontend `.env.local`: `BFF_URL=http://127.0.0.1:4000`. This is server-only; never add a `NEXT_PUBLIC_` prefix. Restart Next after changing it. BFF variables: `PORT`, `COMPOSER_TOKEN`, `DATA_DIR`; see its README. Editor links in this local demo assume port 4000.

Production-mode local check:

```sh
npm run build
npm start
```

Keep the BFF running. Start it with `npm start` in its own directory. If setting its `NODE_ENV=production`, provide a strong `COMPOSER_TOKEN` (24+ characters).

## Runtime architecture

```text
Business editor → draft → validation → publish
                                       ↓
Browser URL → Next Server Component → Node BFF /v1/pages
                                       ↓
                         published composition + catalog + business rules
                                       ↓
Next contract validation ← page JSON (template + sections + props + data)
            ↓
approved React registry → server render → hydrate interactive components
```

BFF composes page structure and data; Next owns templates, styles and executable components. Business users can edit copy, reorder/add approved blocks, target optional blocks to an audience, and add `/wireless/...` pages without code changes. Unknown components and invalid props are rejected. See [BFF documentation](../wireless-bff/README.md).

The single `app/wireless/[[...path]]/page.tsx` supports catalog, device, plan, trade-in, extras, cart, checkout and confirmation routes. New composed paths use it automatically. You can also declare an explicit route such as `app/wireless/offers/page.tsx` that calls the same `getWirelessPage('/wireless/offers')`; explicit Next routes take precedence over the catch-all. Static metadata is shared in this demo.

## Request isolation and state

React Compiler and Cache Components are enabled. A Suspense loading shell surrounds runtime cookies/params and the no-store BFF request. No `use cache`, `unstable_cache` or cross-request QueryClient is used for business data. React `cache()` deduplicates the same page request within one server render. BFF rereads configuration/catalog files per request and sends private/no-store responses. Static JS, styles, registry artifacts and the generic prerendered loading shell remain reusable; they contain no user data. This follows [Next's uncached-data Suspense model](https://nextjs.org/docs/messages/blocking-route).

TanStack Query manages browser quote requests with selection-specific keys, cancellation and request deduplication. Each mounted provider creates its own QueryClient. The server renders catalog/composition data directly from the BFF; quotes are fetched after client workflow state is restored. The sample's selection is a small React context persisted in sessionStorage, so it is **not** an authenticated server cart. For an SSR cart, persist a cart ID in a secure cookie, load the cart in the request-scoped BFF call, and hydrate a per-request QueryClient; never read sessionStorage on the server or create a server-global store. Browser quote caching is distinct from server caching. Orders always revalidate totals and eligibility in the BFF.

The audience switch is an explicitly untrusted demonstration cookie. Switching reloads the page and clears the workflow. The page blueprint button displays the resolved BFF manifest and revision. Reload after publishing to see a new composition; already mounted pages are not pushed live updates.

## Errors, streaming and tests

Unknown pages use the not-found view. BFF timeouts/unavailability use route error handling. Interactive block render failures have a local retry boundary; server render failures use Next route/Suspense handling. Quote and order failures are shown in the relevant component. The page shell streams before the BFF response; this implementation uses **one page JSON response**, not priority-scheduled independent block streams. Separate critical/optional BFF resources and Suspense boundaries are needed for per-block progressive streaming.

```sh
npm test
npm run typecheck
npm run build
```

The contract test compares the frontend registry with the sibling BFF artifact and checks unsupported blocks/props. BFF tests exercise publish behavior and business validation. The existing lightweight Node test runner is retained; Vitest has not been installed in this sample.

## Extend the registry

1. Implement a React block using existing atoms/molecules/organisms. Keep BFF data props serializable.
2. Add its ID to `data/registry.json`, component DTO enum in `lib/wireless/domain.ts`, and renderer map.
3. Define its Zod props contract in `lib/registry-contracts.ts`. Every registered block is available in every template.
4. Update the BFF DTO (`src/contracts.ts`) in the same versioned release. Prefer a shared contract package in a larger app.
5. Generate and release `public/registry.json` to the BFF; deploy the compatible frontend, then compose and publish.

Tradeoffs: fast governed page changes and reusable components, at the cost of schema/version coordination, BFF availability/latency, bounded business-user flexibility and more operational infrastructure. The current payload includes the whole small catalog; larger systems should resolve only page-required data. Component implementations are bundled together here; use an explicit lazy import map for large registries.

All carrier-style content and payments are fictional. This is a local Node deployment, not a hosted production storefront.

## Verification in this workspace

Production build passed with `npm run build -- --webpack` (Turbopack internal port binding was restricted by the execution environment). Both apps passed type checking and contract/business tests. HTTP integration verified draft isolation, preview, publish, changed Next HTML without rebuild, simulated order submission, audience rendering, no-store headers and removed-route 404s. Browser inspection subsequently verified the catalog, device, plan, cart and checkout flow.

## Unrestricted composition (wireless-3)

All registered components are available on every template. Add repeated instances with independent props and data. Each instance has a stable ID and a `main`, `sidebar` or `fullWidth` slot; array order is preserved within each slot. On narrow screens slots stack. Changing templates preserves blocks. An empty page is rejected, and unknown component IDs/invalid props still fail validation.

The new `imageCarousel` reads a named collection through the BFF resolver in `src/resolvers.ts`. Its resolved slides are returned in `manifest.blocks[].data`; the frontend renders local SVG assets. `quoteSummary` is independently registered. Existing commerce blocks continue to share the page catalog and shopping context, so repeated plan selectors intentionally edit the same cart; repeated carousels have independent slide positions. Device configurators only update the shopping selection on interaction, avoiding conflicting mount effects.

Checkout now includes a full-width carousel. Component prerequisites are local: a checkout block prompts for a phone/plan, while other blocks on the same page render normally. Legacy page `requires` metadata no longer gates the page. Removing a checkout block does not bypass the order API's agreements or pricing validation, but it can make the journey incomplete; business authors own the experience they publish.

Add `/wireless/offers` in the composer, save and publish, then open that path: no route file or rebuild is needed. New component implementations still need a deployment. Draft and published configurations were migrated independently, preserving unpublished edits.

## Quick cart and mini-cart details

On the device page, **Next steps** sends `continuePurchase` to Next `/api/wireless/actions`, which proxies BFF `/v1/actions`. Published `flows` maps new line to `quick-cart` and upgrade to direct plan navigation. The quick cart reuses registered cartItem/cartActions/messageBanner blocks inside one accessible native-dialog drawer host. Continue selects a plan; miniCartSummary on subsequent steps opens the `cart-details` surface with cartItem/cartCharges. Quotes and details use the same BFF calculation. Closing uses local UI state; changing a selection closes the previous drawer.

Configure flow outcomes and surface blocks under **Drawer compositions and flow controls** in Composition Studio. Apply JSON, save, then publish. The registry is unrestricted; every registered block can be reused on a page or surface. The surface IDs and action/effect set are typed and currently limited to the demonstrated workflows.

The BFF persists latest action snapshots under data/.runtime, keyed by an HttpOnly demo cart cookie forwarded by Next. Shopping edits still live in browser context/sessionStorage and are sent with each action. This is not authenticated server-cart hydration. Latest-request retry identity is tested; orders remain simulated and lack a production idempotency ledger. See [BFF setup](../wireless-bff/SETUP.md) for exact boundaries and production integration steps.
