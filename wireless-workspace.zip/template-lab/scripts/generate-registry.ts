import { mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { buildPublicRegistry } from "../lib/registry-contracts";

const publicDirectory = resolve(process.cwd(), "public");
mkdirSync(publicDirectory, { recursive: true });
writeFileSync(
  resolve(publicDirectory, "registry.json"),
  `${JSON.stringify(buildPublicRegistry(), null, 2)}\n`,
);
