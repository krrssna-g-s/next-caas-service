'use client';
import {useMutation,useQueryClient} from '@tanstack/react-query';
import {useRouter} from 'next/navigation';
import {useRef} from 'react';
import {surfaceResponseSchema,type Selection} from '@/lib/wireless/domain';
import {useWireless} from './context';
export function useJourneyAction(){
 const {selection,setSurface}=useWireless();const client=useQueryClient();const router=useRouter();const lock=useRef(false);
 const mutation=useMutation({retry:false,mutationFn:async(input:{action:string;selection:Selection;requestId:string})=>{
 const res=await fetch('/api/wireless/actions',{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)});const json=await res.json();if(!res.ok)throw Error(json.error??'Unable to update cart');return surfaceResponseSchema.parse(json);
 },onSuccess:response=>{if(response.cart.quote)client.setQueryData(['wireless','quote',response.cart.selection],response.cart.quote);if(response.effect.type==='openSurface')setSurface(response);else{setSurface(null);router.push(response.effect.href)}}});
 return {...mutation,run:async(action:'continuePurchase'|'showCartDetails'|'continueJourney',next=selection)=>{if(lock.current)return;lock.current=true;try{await mutation.mutateAsync({action,selection:next,requestId:crypto.randomUUID()})}catch{}finally{lock.current=false}}};
}
