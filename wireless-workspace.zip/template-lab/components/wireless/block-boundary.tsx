'use client';
import {Component,type ReactNode} from 'react';
export class BlockBoundary extends Component<{children:ReactNode},{failed:boolean}>{
 state={failed:false};
 static getDerivedStateFromError(){return {failed:true};}
 render(){return this.state.failed?<section className="w-panel" role="alert"><h2>This section is unavailable.</h2><button onClick={()=>this.setState({failed:false})}>Retry section</button></section>:this.props.children;}
}
