'use client';
import {createContext,useContext,useState,useEffect,type ReactNode} from 'react';
import {QueryClient,QueryClientProvider,useQuery} from '@tanstack/react-query';
import {initialSelection,quoteSchema,selectionSchema,type JourneyResponse,type Selection,type WirelessQuote} from '@/lib/wireless/domain';
export type Receipt={id:string;quote:WirelessQuote;status:string;selection:Selection};
function useStateValue(){const [surface,setSurface]=useState<JourneyResponse|null>(null);const [selection,setSelection]=useState<Selection>(initialSelection);const [ready,setReady]=useState(false);const [receipt,setReceipt]=useState<Receipt|null>(null);useEffect(()=>{try{const saved=sessionStorage.getItem('signal-demo-v1');if(saved)setSelection(selectionSchema.parse(JSON.parse(saved)));}catch{}setReady(true)},[]);useEffect(()=>{if(ready)try{sessionStorage.setItem('signal-demo-v1',JSON.stringify(selection))}catch{}},[selection,ready]);return {surface,setSurface,selection,ready,receipt,setReceipt,update:(patch:Partial<Selection>)=>{setSurface(null);setSelection(s=>({...s,...patch}));setReceipt(null)},reset:()=>{setSurface(null);setSelection(initialSelection);setReceipt(null)}};}
const Context=createContext<ReturnType<typeof useStateValue>|null>(null);
export function WirelessProvider({children}:{children:ReactNode}){const value=useStateValue();const [client]=useState(()=>new QueryClient({defaultOptions:{queries:{retry:1,staleTime:0,refetchOnWindowFocus:false}}}));return <QueryClientProvider client={client}><Context.Provider value={value}>{children}</Context.Provider></QueryClientProvider>}
export function useWireless(){const value=useContext(Context);if(!value)throw Error('WirelessProvider missing');return value;}
export function useWirelessQuote(){
 const {selection,ready}=useWireless();
 const query=useQuery({queryKey:['wireless','quote',selection],enabled:ready&&!!selection.device&&!!selection.plan,queryFn:async({signal})=>{
 const response=await fetch('/api/wireless/quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(selection),signal,cache:'no-store'});
 const data=await response.json();if(!response.ok)throw Error(data.error??'Quote unavailable');return quoteSchema.parse(data);
 }});
 return {quote:query.data??null,error:query.error?.message??''};
}
