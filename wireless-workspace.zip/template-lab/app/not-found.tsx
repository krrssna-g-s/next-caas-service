import Link from 'next/link';
export default function NotFound(){return <main className="fallback"><p>404 / PAGE NOT FOUND</p><h1>No wireless page is published here.</h1><Link href="/wireless">Return to phones →</Link></main>}
