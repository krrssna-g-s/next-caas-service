'use client';
export default function GlobalError(){return <html lang="en"><body><h1>The experience is unavailable.</h1><button onClick={()=>window.location.reload()}>Reload</button></body></html>}
