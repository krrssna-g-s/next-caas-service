'use client';
export default function ErrorPage(){return <main className="fallback" role="alert"><h1>We couldn’t load this experience.</h1><p>Check that the Node.js BFF is running on port 4000, then try again.</p><button onClick={()=>window.location.reload()}>Reload page</button></main>}
