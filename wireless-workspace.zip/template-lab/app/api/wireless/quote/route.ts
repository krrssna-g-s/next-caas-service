import {proxyBff} from '@/lib/wireless/bff';
export async function POST(request:Request){return proxyBff(request,'/v1/quote')}
