import {WirelessProvider} from '@/components/wireless/context';
import './wireless.css';
export default function Layout({children}:{children:React.ReactNode}){return <WirelessProvider>{children}</WirelessProvider>}
