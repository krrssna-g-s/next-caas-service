import {Suspense} from 'react';
import {notFound} from 'next/navigation';
import {getWirelessPage} from '@/lib/wireless/bff';
import {WirelessRenderer} from '@/components/wireless/renderer';
export const metadata={title:'Signal | Wireless composition demo'};
type Props={params:Promise<{path?:string[]}>};
export default function Page(props:Props){return <Suspense fallback={<main className="fallback" role="status">Composing your wireless experience…</main>}><RuntimePage {...props}/></Suspense>}
async function RuntimePage({params}:Props){const {path=[]}=await params;const data=await getWirelessPage('/wireless'+(path.length?'/'+path.join('/'):''));if(!data)notFound();return <WirelessRenderer {...data}/>}
