import {z} from 'zod';
import registry from '@/public/registry.json';
export function assertPageRegistry(template:string,blocks:{id:string;component:string;props:Record<string,unknown>}[]){
 if(!registry.templates.some(t=>t.id===template))throw Error('Unsupported template');
 if(new Set(blocks.map(b=>b.id)).size!==blocks.length)throw Error('Duplicate block instance ID');
 for(const block of blocks){const c=registry.components.find(c=>c.id===block.component);if(!c)throw Error('Unsupported component');z.fromJSONSchema(c.props as Parameters<typeof z.fromJSONSchema>[0]).parse(block.props);}
}
