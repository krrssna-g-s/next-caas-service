import {z} from 'zod';
export const bannerSchema=z.object({title:z.string().min(1).max(140),body:z.string().max(600),tone:z.enum(['info','success'])}).strict();
