import rawRegistry from '@/data/registry.json';
export const componentRegistry=rawRegistry;
