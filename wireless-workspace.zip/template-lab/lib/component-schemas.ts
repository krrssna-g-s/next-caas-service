import {z} from 'zod';
export const carouselConfigSchema=z.object({collection:z.enum(['checkout-offers','phone-highlights']),title:z.string().min(1).max(140)}).strict();
export const carouselDataSchema=z.object({slides:z.array(z.object({src:z.string().regex(/^\/wireless-media\/[a-z0-9-]+\.svg$/),alt:z.string(),caption:z.string()})).min(1).max(12)});
export const deviceConfigSchema=z.object({deviceId:z.string().max(80).optional()}).strict();
