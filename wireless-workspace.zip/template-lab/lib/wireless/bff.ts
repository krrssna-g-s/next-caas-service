import 'server-only';
import {cache} from 'react';
import {cookies} from 'next/headers';
import {wirelessRendererPropsSchema} from './domain';
import {assertPageRegistry} from '@/lib/published-registry';
export const getWirelessPage=cache(async(path:string)=>{
 const cookieStore=await cookies();const audience=cookieStore.get('demo-audience')?.value==='existing'?'existing':'new';
 const response=await fetch(`${process.env.BFF_URL??'http://127.0.0.1:4000'}/v1/pages?path=${encodeURIComponent(path)}`,{cache:'no-store',headers:{'X-Demo-Audience':audience},signal:AbortSignal.timeout(8000)});
 if(response.status===404)return null;if(!response.ok)throw Error('Composition BFF unavailable');
 const data=wirelessRendererPropsSchema.parse(await response.json());
 if(data.composition.registryVersion!=='wireless-3')throw Error('Registry deployment mismatch');
 assertPageRegistry(data.manifest.template,data.manifest.blocks);return data;
});
export async function proxyBff(request:Request,path:'/v1/quote'|'/v1/orders'|'/v1/actions'){
 try{const cookieStore=await cookies();const origin=request.headers.get('origin');if(origin&&new URL(origin).host!==request.headers.get('host'))return Response.json({error:'Cross-origin request denied'},{status:403});const cartId=cookieStore.get('signal-cart')?.value??crypto.randomUUID();const body=await request.text();if(body.length>256000)return Response.json({error:'Request too large'},{status:413});
 const response=await fetch(`${process.env.BFF_URL??'http://127.0.0.1:4000'}${path}`,{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json','X-Cart-Id':cartId,'X-Demo-Audience':cookieStore.get('demo-audience')?.value==='existing'?'existing':'new'},body,signal:AbortSignal.timeout(8000)});
 return new Response(await response.text(),{status:response.status,headers:{'Content-Type':'application/json','Cache-Control':'private, no-store',...(path==='/v1/actions'?{'Set-Cookie':`signal-cart=${cartId}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400${new URL(request.url).protocol==='https:'?'; Secure':''}`}:{})}});
 }catch{return Response.json({error:'The BFF is unavailable. Please retry.'},{status:502,headers:{'Cache-Control':'private, no-store'}})}
}
