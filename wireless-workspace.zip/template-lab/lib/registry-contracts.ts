import {z} from 'zod';
import {componentRegistry} from './registry';
import {bannerSchema} from './banner-schema';
import {carouselConfigSchema,deviceConfigSchema} from './component-schemas';
export function buildPublicRegistry(){return {schemaVersion:4,version:'wireless-3',components:componentRegistry.components.map(c=>({...c,props:z.toJSONSchema(c.id==='messageBanner'?bannerSchema:c.id==='imageCarousel'?carouselConfigSchema:c.id==='deviceConfigurator'?deviceConfigSchema:z.object({}).strict())})),templates:componentRegistry.templates};}
