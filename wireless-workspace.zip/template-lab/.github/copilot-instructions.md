# Copilot Instructions for Template Lab

## Build, Test, and Lint

**Setup**
```bash
npm ci                 # Install dependencies (uses lock file)
```

**Development**
```bash
npm run dev            # Start Next.js dev server (http://localhost:3000)
npm run build          # Production build
npm start              # Run production server
```

**Testing & Quality**
```bash
npm test               # Run all tests in tests/*.test.ts (Node.js test runner)
npm test -- tests/pages.test.ts       # Run single test file
npm run typecheck      # Type-check entire project (no emit)
npm run build          # Includes type-checking
```

## High-Level Architecture

This is a **configuration-driven Next.js storefront** that separates content (JSON) from templates and components:

```
Request → catch-all [[...slug]]/page.tsx
  ↓
  BFF layer (server-only): lib/bff.ts, lib/resolve-page.ts
  ↓
  Registry metadata: data/registry.json → lib/registry.ts
  ↓
  Zod-validated PageDefinition: lib/schema.ts
  ↓
  Page Renderer: components/page-renderer.tsx
  ↓
  Template class + theme tokens + registered components
```

**Three distinct content paths:**
- `/` and `/collections/*` and `/journal/*`: Rendered by catch-all route with BFF payload
- `/cart` and `/payment`: Explicit routes with commerce state management
- `/wireless`: Dedicated wireless device journey with its own routing

**Key design principles:**
1. **Server-side composition**: JSON selects components and sets props; rendering is server-side.
2. **BFF boundary**: `lib/bff.ts` and related functions are `server-only`; they aggregate data, validate with Zod, and return serializable responses.
3. **No global data fetch**: Each page or section can fetch independently (see streaming example).
4. **Graceful schema evolution**: Schema validation happens at BFF boundary; unknown components are rejected before rendering.

## Content System

**Pages are defined in `data/pages.json`:**
- `path`: URL route (string, local absolute path)
- `template`: "catalog", "campaign", or "editorial"
- `theme`: "sage", "sand", or "ink"
- `metadata`: title and description
- `sections`: array of validated component definitions

**To add a new page:**
1. Add entry to `data/pages.json` with a unique path and registered template/theme
2. Sections reference registered components (hero, productGrid, features, article)
3. No new route file needed; the catch-all handles it

## Component Registration & Schema

**To add a new component:**
1. Add its ID, description, and allowed rendering contexts to `data/registry.json`
2. Extend the discriminated union in `lib/schema.ts` with its Zod props schema
3. Implement the React component and add it to the typed renderer registry
4. Add the ID to each `data/registry.json` template that may compose it
5. Reference the ID and schema-valid props in a page's JSON sections

The JSON registry is declarative metadata and an allowlist; it never contains
executable code or import paths. `lib/registry.ts` validates the manifest and
provides helpers used by storefront, streaming, and wireless configuration
validation. React implementations stay in TypeScript: storefront sections are
bound in `components/page-renderer.tsx`, while wireless workflow components
are bound in `components/wireless/renderer.tsx`.

**Reusing a component on another page:** `productGrid` is listed in both the
storefront `catalog` and `streaming` template definitions in
`data/registry.json`. The storefront page entry in `data/pages.json` and the
streaming section in `data/streaming.json` both select that ID. Their payloads
must satisfy the `productGrid` props schema in `lib/schema.ts`; the renderer
maps that ID to the compiled `ProductGrid` implementation in
`components/product-grid.tsx`. To use it elsewhere, allow the ID in that
template's registry definition and provide valid props; no new component copy
or import path in JSON is needed.

**Template representation:** Storefront template IDs are validated against
`data/registry.json` and map to CSS classes in `components/page-renderer.tsx`.
Wireless template IDs are validated against the same manifest and select the
wireless wrapper class in `components/wireless/renderer.tsx`. Keep template
IDs distinct from component IDs; templates define which component IDs they can
compose.

**Schema validation flow:**
- Zod schema in `lib/schema.ts` defines all valid component types and prop shapes
- `resolvePage()` validates entire page definition
- Rendering fails safely if schema is violated (never reaches component)
- Custom refinement checks section ID uniqueness

## Streaming & Async Sections

**Streaming demo at `/streaming`:**
- Manifest in `data/streaming.json` configures sections with priority (P1/P2) and simulated delays
- BFF in `lib/streaming-bff.ts` returns independent promises for each section
- Rendering in `app/streaming/page.tsx` wraps sections in Suspense; shell renders immediately
- **Priority is a convention, not a Next.js guarantee**: each section awaits its own promise inside Suspense; design ensures P1 appears before P2

**Key pattern:**
- Keep the page manifest small and cached
- Each section fetches independently (replace timer mocks with real fetches)
- Avoid awaiting all sections at the page root
- Section timeouts must be explicit (not all section requests at once)

## Commerce (Cart & Checkout)

**Explicit routes at `/cart` and `/payment`:**
- State lives in component (sessionStorage for cart, React state for checkout)
- Quote and order APIs at `api/checkout/{quote,order}` and `api/wireless/{quote,order}`
- Server recalculates totals and validates stock/consent before returning results
- Promo code `FORMA10` grants 10% discount

**Validation contract:**
- Server is authoritative for prices, discounts, tax, shipping, and consent requirements
- Client-supplied values (prices, totals) are never trusted
- Cart is session-local; persists via sessionStorage until full reload

**Key files:**
- `lib/commerce.ts`: Catalog, pricing rules, validation schemas
- `components/commerce/`: CartPage, CheckoutPage, cart context
- `lib/wireless/domain.ts`: Wireless-specific pricing and state

## Testing Conventions

**Use Node.js test runner** (no external framework):
```typescript
import { test } from 'node:test';
import assert from 'node:assert/strict';

test('description', () => {
  assert.equal(actual, expected);
});
```

**What to test:**
- BFF payload validation (schema enforcement)
- Commerce calculations (pricing, discounts, tax)
- Page resolution and routing
- Graceful errors (invalid paths, schema violations)

**Current test files:**
- `tests/pages.test.ts`: Page resolution, schema validation
- `tests/commerce.test.ts`: Cart, pricing, discounts
- `tests/wireless.test.ts`: Wireless journey state and pricing

## Key Conventions

1. **Path imports**: Use `@/*` alias for absolute imports (defined in tsconfig.json)
2. **Server-only modules**: Files directly imported in Server Components should explicitly import `'server-only'` (e.g., BFF, commerce services)
3. **Type inference**: Use `z.infer<typeof schema>` for type definitions from Zod schemas
4. **Discriminated unions**: Component schemas use `z.discriminatedUnion("component", [...])` for safe type narrowing in the renderer
5. **Dynamic rendering**: Pages use `export const dynamic = 'force-dynamic'` for per-request rendering (no caching)
6. **API routes**: Route handlers in `app/api/` are thin wrappers that call BFF/domain functions
7. **Fragment pattern**: Main layout in `app/layout.tsx`; nested layouts in route folders (e.g., `wireless/layout.tsx`)

## Gotchas & Design Boundaries

- **Configuration does not enforce business logic**: Validation happens at the BFF boundary, not in schema alone.
- **Serialization matters**: Only pass serializable props to Client Components (no functions, complex objects, or circular refs).
- **Cache strategy varies**: Public templates can cache; user carts, quotes, and stock checks must not share caches.
- **Catch-all routes**: `[[...slug]]/page.tsx` handles undefined paths; explicit routes (like `/cart`) take precedence. Invalid paths return 404.
- **Transactions**: Checkout is a simplified demo; real systems need idempotency keys, durable state machines, and proper error recovery.
