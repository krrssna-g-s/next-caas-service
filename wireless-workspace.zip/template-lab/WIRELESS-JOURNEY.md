# Wireless journey

`/wireless` → `/wireless/phones/aurora-pro` → `/wireless/plan` → `/wireless/trade-in` → `/wireless/extras` → `/wireless/cart` → `/wireless/checkout` → `/wireless/confirmation`.

Choose a phone, storage, color, installment/full purchase, line/number options, plan, trade-in, protection/perks/accessories, shipping and simulated payment. Required agreements vary with installment and trade-in choices. Quotes and orders are validated by the separate Node BFF. Confirmation exists only in the current browser session's memory; no real order is placed.

Use the **Composition Studio** link to change page headings, block order and optional audience-specific banners; save and publish, then reload the storefront. Use **Page blueprint** to inspect the resolved response. See [setup and limitations](README.md).

The device Next steps button now opens a quick-cart drawer for new lines; upgrades navigate directly to plan. Plan and later steps include a mini-cart summary with Details opening the price-breakdown drawer. Both are driven by published BFF flow/surface configuration.
