# Architecture

See [README](README.md) for the current runtime architecture, state/caching boundaries, registry workflow, error handling and tradeoffs. See the [separate BFF README](../wireless-bff/README.md) for composition publishing and API contracts. Earlier generic template demos have been removed.
