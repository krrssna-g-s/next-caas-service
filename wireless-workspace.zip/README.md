# Wireless composition workspace

- [Frontend setup and architecture](template-lab/README.md)
- [Separate Node BFF setup](wireless-bff/SETUP.md)
- [BFF APIs and publishing](wireless-bff/README.md)
- [Production Next.js/TanStack setup guidance](nextjs-tanstack-guide/README.md)
- [Agent skill installation](nextjs-tanstack-guide/INSTALL.md)
- [BFF actions and drawer surfaces](nextjs-tanstack-guide/skills/next-template-pages/references/bff-and-surfaces.md)

Run the BFF on 4000 and Next on 3000. Start at /wireless; author at :4000/composer. The local token is local-composer-demo. The package contains fictional shopping data; no actual carrier/payment/AI integration is configured.

The working sample uses Node's test runner; the production setup guide recommends Vitest. Server-rendered pages and client interaction work in the sample; authenticated SSR cart hydration is a documented extension, not implemented. Source archives exclude node_modules, build output, local environment files and runtime cart snapshots.

For your work machine: [separate-repository prompt](nextjs-tanstack-guide/WORK-MACHINE-PROMPT.md) and [UI monorepo / registry release setup](nextjs-tanstack-guide/MONOREPO-REGISTRY-SETUP.md). These are target setup instructions; the runnable local sample has not been moved into private published packages.
