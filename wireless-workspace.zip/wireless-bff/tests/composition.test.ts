import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,cp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createRepository} from '../src/composition.ts';
import {wirelessQuote,validateWirelessOrder} from '../src/business.ts';
import {initialSelection} from '../src/contracts.ts';
test('draft isolation, publish visibility, audience rules and optimistic concurrency',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'composition-'));try{
 await cp(new URL('../data/',import.meta.url),dir,{recursive:true});const repo=createRepository(dir);
 const draft=await repo.read('draft');const before=await repo.compose('/wireless','new');draft.pages[0].title='Published without rebuilding';
 const saved=await repo.save(draft,draft.revision);
 assert.equal((await repo.compose('/wireless','new')).manifest.title,before.manifest.title);
 assert.equal((await repo.compose('/wireless','new','draft')).manifest.title,draft.pages[0].title);
 await assert.rejects(repo.save(draft,draft.revision),/Draft changed/);
 await repo.publish(saved.revision);assert.equal((await repo.compose('/wireless','new')).manifest.title,draft.pages[0].title);
 assert.ok((await repo.compose('/wireless','new')).config.perks.some(p=>p.id==='travel'));
 assert.ok(!(await repo.compose('/wireless','existing')).config.perks.some(p=>p.id==='travel'));
 const bad=structuredClone(saved);bad.pages[0].blocks[0].component='executeCode';await assert.rejects(repo.save(bad,saved.revision));
 const missing=structuredClone(saved);missing.pages=missing.pages.filter(p=>p.path!=='/wireless/checkout');await repo.save(missing,saved.revision);
 await assert.rejects(repo.compose('/payment','new'),/not found/);
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('BFF recalculates totals and requires applicable agreements',async()=>{
 const repo=createRepository(new URL('../data/',import.meta.url).pathname);const config=await repo.catalog();const device=config.devices[0];
 const selection={...initialSelection,device:device.id,color:device.colors[0],storage:device.storage[0].label,plan:'plus' as const};const quote=wirelessQuote(selection,config);
 const order={selection,contact:{name:'Demo User',email:'demo@example.com',address:'1 Demo Street',city:'Demo City',zip:'10001'},payment:'demo_card',eligibility:'approved',agreements:['service','electronic','installment'],version:'wireless-demo-v1',expectedToday:quote.today,expectedMonthly:quote.monthly};
 assert.equal(validateWirelessOrder(order,config).status,'demo_confirmed');
 assert.throws(()=>validateWirelessOrder({...order,expectedToday:0},config),/quote changed/);
 assert.throws(()=>validateWirelessOrder({...order,agreements:[]},config),/Accept/);
 assert.throws(()=>validateWirelessOrder({...order,payment:'demo_decline'},config),/declined/);
});

test('all registered components can be placed in every template; duplicate instances resolve independently',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'plug-play-'));try{
 await cp(new URL('../data/',import.meta.url),dir,{recursive:true});const repo=createRepository(dir);let draft=await repo.read('draft');const registry=await repo.registry();
 const props=(id:string)=>id==='messageBanner'?{title:'First',body:'Business copy',tone:'info'}:id==='imageCarousel'?{title:'Gallery',collection:'checkout-offers'}:{};
 for(const template of registry.templates){
 draft.pages[0].template=template.id;draft.pages[0].blocks=registry.components.map((c,i)=>({id:'block-'+i,component:c.id,props:props(c.id),audience:'all' as const,slot:'main' as const}));
 draft=await repo.save(draft,draft.revision);
 }
 const page=draft.pages.find(p=>p.path==='/wireless/checkout')!;
 page.blocks=[{id:'first',component:'imageCarousel',props:{title:'First',collection:'checkout-offers'},audience:'all',slot:'main'},{id:'second',component:'imageCarousel',props:{title:'Second',collection:'phone-highlights'},audience:'all',slot:'sidebar'}];
 draft=await repo.save(draft,draft.revision);await repo.publish(draft.revision);
 const response=await repo.compose('/wireless/checkout','new');assert.equal(response.manifest.blocks.length,2);assert.equal(response.manifest.blocks[1].props.title,'Second');assert.notDeepEqual(response.manifest.blocks[0].data,response.manifest.blocks[1].data);
 draft.pages.push({...structuredClone(page),path:'/wireless/brand-new-page'});draft=await repo.save(draft,draft.revision);await repo.publish(draft.revision);assert.equal((await repo.compose('/wireless/brand-new-page','new')).manifest.path,'/wireless/brand-new-page');
 const duplicate=structuredClone(draft);duplicate.pages[0].blocks[1].id=duplicate.pages[0].blocks[0].id;await assert.rejects(repo.save(duplicate,draft.revision),/instance ID/);
 await rm(join(dir,'media.json'));const degraded=await repo.compose('/wireless/checkout','new');assert.ok(degraded.manifest.blocks[0].error);
 }finally{await rm(dir,{recursive:true,force:true});}
});
