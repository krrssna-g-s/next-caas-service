# Wireless composition BFF

A separate Node.js/TypeScript application. Owns catalog data, business rules, page composition, quote calculation and simulated order validation. The sibling Next.js application owns React implementations and exports their allowed contract as JSON.

## Run

Use Node.js 22.13+ and npm. From this directory:

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:4000/composer. Enter the local demo token `local-composer-demo`, then Load. For a custom token run `COMPOSER_TOKEN=your-token npm run dev`. Environment variables are read from the process (this app does not automatically load `.env`). Start the Next.js app separately; see its README.

## Business composition workflow

1. Select a wireless page; change heading/copy, reorder blocks, or add a registered message banner.
2. Choose an audience for optional blocks. Every block can be removed or audience-targeted; order business rules remain enforced by the API.
3. Save draft. Preview shows the **saved draft's composed JSON**, including business rules for the selected audience.
4. Publish saved draft. Reload the storefront: the next request reads the new composition, without a Next.js rebuild.
5. Add a page such as `/wireless/offers` using the editor. Its runtime route uses the existing Next catch-all. Every registered component is available on every page.

Draft and published documents are separate files. Saves use revision checks; stale editors receive 409. File replacement is atomic and writes are serialized in this process. A new component implementation requires a frontend deployment and a registry release; business users can only compose approved components. Repeated components are supported through unique instance IDs. Layouts are approved template IDs, not arbitrary CSS/JavaScript.

## APIs

All responses use `Cache-Control: private, no-store`.

| Method | Route | Purpose |
|---|---|---|
| GET | `/health` | Process health |
| GET | `/v1/registry` | Imported frontend registry |
| GET | `/v1/pages?path=/wireless` | Published, business-rule-resolved page JSON |
| POST | `/v1/quote` | Validate selection and calculate prices |
| POST | `/v1/orders` | Recalculate totals, validate agreements and simulate order |
| GET | `/admin/composition` | Draft, published document and registry |
| PUT | `/admin/composition` | Save `{expectedRevision, composition}` |
| GET | `/admin/preview?path=/wireless&audience=new` | Compose saved draft |
| POST | `/admin/publish` | Publish `{expectedRevision}` |

Admin routes require `Authorization: Bearer <COMPOSER_TOKEN>`. For the demo only, `X-Demo-Audience: existing` selects existing-customer rules (travel perk unavailable). Never use this caller-controlled header as real authentication or eligibility. A production BFF must derive identity and entitlements from a verified session/token.

Response structure uses `composition`, `manifest`, `device` and shared catalog `config`. The manifest includes ordered `blocks`:

```json
{
  "id": "checkout-gallery-1",
  "component": "imageCarousel",
  "slot": "fullWidth",
  "props": {"title": "Explore", "collection": "checkout-offers"},
  "data": {"slides": [{"src": "/wireless-media/connected.svg", "alt": "Illustrated phone", "caption": "Stay connected"}]}
}
```

`src/resolvers.ts` resolves each instance's data concurrently within the request. Collection names map to trusted local `data/media.json`; author configuration never supplies executable code or arbitrary network endpoints. Failures produce an error on that instance instead of failing unrelated blocks. Existing commerce components use the shared catalog payload and browser shopping context; the carousel and explicit-device resolver demonstrate per-instance BFF data resolution. `sections` remains a derived list for journey indicators, but rendering uses `blocks` and stable instance IDs.

All templates accept all components. Template IDs select presentation, not allowed business capabilities. Slots are `main`, `sidebar`, `fullWidth`. Block props and data remain validated. Page `requires` is legacy metadata; the renderer applies prerequisites only to individual shopping blocks. A business user can remove essential UI, so publishing responsibility remains with the author; the order API always enforces required agreements and trusted prices.

## Registry release

In the frontend run `npm run generate:registry`. Copy its `public/registry.json` into this app's `data/registry.json`. Both apps validate component props and instance IDs. When changing the contract, increment the version in frontend `lib/registry-contracts.ts`, its BFF-version check, and compositions together. Deploy the compatible frontend before publishing a composition using new components. Tests compare both artifacts when sibling directories are present. For separate repositories, distribute this versioned artifact through CI or a private schema package. Avoid fetching a mutable registry on each request.

## Validation

```sh
npm test
npm run typecheck
```

Tests cover draft/publish separation, audience isolation, stale writes, unknown components, cross-template placement, repeated instances, resolver failure isolation, quote tampering, required agreements and payment decline. They use temporary files and do not modify live compositions. Tests currently use Node's built-in test runner with TypeScript via tsx.

## Production boundaries

This is a local runnable proof of concept. Bind address is loopback. JSON files are configuration storage, not a data-response cache; catalog and composition are reread each call. There is no Redis, process-wide response cache or external API cache. The serial queue only coordinates writes.

For multiple instances, replace files with transactional persistent storage, revision compare-and-swap, publish history, rollback and audit records. Add editor SSO/RBAC, tenant isolation, rate limits and observability. Keep BFF behind a trusted gateway and configure HTTPS, allowed origins and proxy limits. The local shared token is not enterprise identity. `NODE_ENV=production` requires a configured token of at least 24 characters.

Payments, addresses, eligibility and agreements are demonstration inputs; no actual payment processing, order persistence, idempotent fulfillment or carrier integration exists. Do not enter real personal/payment data. An AI concierge can propose the same approved component/action contracts, but this app does not implement a model endpoint. Validate its output and use authenticated BFF actions; never allow generated code or prices to become authoritative.

## Full setup and action surfaces

Read [SETUP.md](SETUP.md) for installation, registry release, drawer/flow authoring, `/v1/actions`, file-backed cart snapshots, bounded retry protection, test commands and production limitations. Page and surface definitions share the draft/publish lifecycle.
