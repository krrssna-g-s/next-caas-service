# Set up the separate Node.js BFF

This is the installation guide for the delivered runnable app, contract version `wireless-3`. Keep `wireless-bff`, `template-lab` and `nextjs-tanstack-guide` as sibling folders when using the supplied cross-app contract test.

## 1. Runtime and packages

Use Node.js 22.13+ and npm. From `wireless-bff`:

```sh
npm ci
npm run typecheck
npm test
node --import tsx src/server.ts
```

The server listens on `127.0.0.1:4000`. `npm run dev` uses tsx watch. Dependencies are Zod for runtime validation, TypeScript/@types/node for types, and tsx for TypeScript execution. The HTTP server uses Node's built-in HTTP module. The lockfile pins the delivered versions. No Express, Redis or database service is required for this local demonstration.

For a newly created empty Node repo, the equivalent baseline is:

```sh
npm init -y
npm pkg set type=module
npm install zod
npm install -D typescript tsx @types/node
```

Copy this app's `src`, `data`, `public`, `tests`, `tsconfig.json` and scripts as the implementation; the install commands alone do not create an engine.

## 2. Configuration

The process reads `PORT` (default 4000), `DATA_DIR` (default this app's data folder), and `COMPOSER_TOKEN`. Variables must be supplied by the shell or environment manager; `.env.example` is documentation and is not automatically loaded. For example:

```sh
PORT=4000 COMPOSER_TOKEN=local-composer-demo node --import tsx src/server.ts
```

Open http://127.0.0.1:4000/composer and load with `local-composer-demo`. A production-mode process requires an explicit token of 24+ characters, but that check does not make the shared-token editor production authentication.

## 3. Connect Next.js

In `template-lab/.env.local`:

```dotenv
BFF_URL=http://127.0.0.1:4000
```

Then run `npm ci` and `npm run dev` in that folder. For production-mode local verification run `npm run build -- --webpack` then `npm start`. Open http://127.0.0.1:3000/wireless. Never expose BFF_URL or the editor token as NEXT_PUBLIC credentials.

Browser calls go through Next's `/api/wireless/*` routes. Next forwards the current demo audience and, for actions, an HttpOnly `signal-cart` cookie as `X-Cart-Id`. The BFF is loopback-only. This header is a local trusted-proxy convention, not production authentication: enforce service authentication and ownership against the current user before exposing a deployed BFF.

## 4. Registry and composition

Generate the frontend contract with `npm run generate:registry` in `template-lab`, then copy `public/registry.json` to `wireless-bff/data/registry.json`. Frontend implementations and BFF contracts must use the same version. Release a compatible frontend before publishing new component names.

- `data/draft.json`: business edits, including pages, surfaces and flow controls.
- `data/published.json`: live version read on each request.
- `data/registry.json`: released component props/schema metadata.
- `data/catalog.json`: fictional products/plans/prices.
- `data/media.json`: named image collections.
- `src/composition.ts`: validation, revision checks, atomic publishing and page resolution.
- `src/resolvers.ts`: trusted per-block data resolution.
- `src/journey.ts`: action validation, cart snapshots and effects.
- `src/business.ts`: authoritative quote and order validation.

All registered components are available in all templates. Each block instance has its own ID, props, data and slot. Drawer blocks use the same registry. Business users cannot supply executable JS, arbitrary import paths or fetch URLs.

## 5. Configure drawer behavior

In the composer expand **Drawer compositions and flow controls**. Edit the flows/surfaces JSON, click **Apply drawer configuration to draft**, then **Save draft → Publish**. This editor section is JSON-based, not a visual drawer designer.

```json
{"new":"quick-cart","upgrade":"plan"}
```

This maps the selection's demo line type to either the quick-cart surface or direct plan navigation. It is a demonstration flow choice, not verified customer eligibility. `showCartDetails` opens `cart-details`; `continueJourney` navigates to `/wireless/plan`.

The two configured surfaces are `quick-cart` and `cart-details`. Each has a title and an ordered array of registered blocks. Change the order, insert message banners or carousels, or reuse any registered component. Current surface IDs and supported effects are deliberately a small typed set; adding another ID/effect requires extending the contracts and handler first.

## 6. API contract

| Method | Endpoint | Role |
|---|---|---|
| GET | `/v1/pages?path=/wireless/offers` | Published page composition + data |
| GET | `/v1/registry` | Released registry |
| POST | `/v1/quote` | Validated selection → quote |
| POST | `/v1/orders` | Validate demo order, totals and agreements |
| POST | `/v1/actions` | Action + selection + requestId → cart snapshot + effect |
| GET | `/admin/composition` | Load authoring workspace |
| PUT | `/admin/composition` | Save composition with expectedRevision |
| POST | `/admin/publish` | Publish saved expectedRevision |
| GET | `/admin/preview?path=/wireless` | Saved draft page JSON |

Admin endpoints require a bearer composer token. Action input:

```json
{"action":"continuePurchase","selection":{"device":"..."},"requestId":"a-generated-UUID"}
```

The selection above is abbreviated; use the complete `selectionSchema`. Valid action names are `continuePurchase`, `showCartDetails`, `continueJourney`. Response shape is `{cart, effect}`; effect is either `{type:"openSurface", surface:{id,title,blocks}}` or `{type:"navigate",href:"/wireless/plan"}`. The cart includes version, device, selection and quote (null until a plan is chosen).

## 7. State, retries and caching

The BFF persists the latest cart action snapshot in `data/.runtime/<cartId>.json`. These files are durable demo application state, not a cross-request response cache. No card/contact details are written there. `.runtime` is excluded from distributed source archives. Do not commit it.

The latest action request ID and fingerprint are retained per cart. Repeating that latest request returns its recorded result; reusing it with different input fails. This is bounded demo retry protection, not a durable ledger for arbitrary delayed retries. Writes are serialized only within one process. For production use a transactional cart database, per-cart optimistic concurrency, an idempotency ledger, access checks, expiry and multi-instance coordination. Orders still simulate confirmation and are not persisted or payment-idempotent.

Page, catalog and composition reads are fresh per request. Responses are private/no-store. React request-scoped deduplication in Next is allowed. The existing shopping draft remains browser React context/sessionStorage; snapshots are saved on actions. There is no cart-read endpoint or SSR hydration from those snapshots yet. Add that explicitly for an authenticated server cart. Opening Details sends the current selection, so its prices use the same BFF calculation as the summary, then updates the matching TanStack quote key.

## 8. Verification and troubleshooting

Run `npm test` and `npm run typecheck` in this BFF, and `npm test` plus a production build in Next. Tests cover publication, unrestricted placement, duplicate instances, resolver failure isolation, business validation, action effects, independent sessions and immediate retry identity.

In the browser: select a phone → Next steps → quick cart → Next steps → plan → choose plan → Details → charges. Press Escape to close. Choose Upgrade on the device page to test direct navigation. Try the composed `/wireless/offers` page.

- Registry mismatch: regenerate/copy the matching artifact and migrate compositions together.
- Drawer missing: verify published flow, action response and selected new/upgrade line type.
- Changes invisible: apply JSON changes, save, publish, and reload the storefront.
- Port occupied: stop the previous local process before starting the same port.
- tsx IPC sandbox error: use `node --import tsx src/server.ts` instead of the tsx CLI.
- Next build port-binding restriction: use `npm run build -- --webpack`.

This is a fictional local journey. Production auth, real carrier eligibility, payment integration, server cart hydration and an AI model endpoint remain integration work.
