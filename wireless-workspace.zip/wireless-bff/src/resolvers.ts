import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {carouselConfigSchema,carouselDataSchema,deviceConfigSchema} from './component-schemas.ts';
import type {WirelessConfig,Device} from './contracts.ts';
// Code-owned resolvers: composition never supplies URLs, executable code or pricing.
export async function resolveBlockData(block:{component:string;props:Record<string,unknown>},config:WirelessConfig,device:Device|null,directory:string):Promise<Record<string,unknown>>{
 switch(block.component){
 case 'imageCarousel':{
 const props=carouselConfigSchema.parse(block.props);
 const collections=JSON.parse(await readFile(join(directory,'media.json'),'utf8'));
 return carouselDataSchema.parse(collections[props.collection]);
 }
 case 'deviceConfigurator':{
 const {deviceId}=deviceConfigSchema.parse(block.props);
 const resolved=deviceId?config.devices.find(d=>d.id===deviceId):device;
 if(deviceId&&!resolved)throw Error('Unknown configured device');
 return {device:resolved??null};
 }
 default:return {};
 }
}
