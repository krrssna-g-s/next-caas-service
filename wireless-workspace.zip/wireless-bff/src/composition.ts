import {surfaceSchema,flowSchema} from './surface-contracts.ts';
import {readFile,writeFile,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {z} from 'zod';
import {resolveBlockData} from './resolvers.ts';
import {configSchema,wirelessRendererPropsSchema} from './contracts.ts';
export class AppError extends Error{constructor(public status:number,message:string){super(message)}}
const block=z.object({id:z.string().regex(/^[a-zA-Z0-9_-]+$/).max(80),component:z.string(),slot:z.enum(['main','sidebar','fullWidth']).default('main'),props:z.record(z.string(),z.unknown()),audience:z.enum(['all','new','existing'])}).strict();
const page=z.object({path:z.string().regex(/^\/wireless(?:\/[a-zA-Z0-9:_-]+)*$/),template:z.string(),title:z.string().min(1).max(160),eyebrow:z.string().max(100),description:z.string().max(600),requires:z.enum(['device','plan']).optional(),blocks:z.array(block).min(1).max(32)}).strict();
export const compositionSchema=z.object({revision:z.number().int().positive(),registryVersion:z.string(),surfaces:z.array(surfaceSchema).length(2),flows:flowSchema,pages:z.array(page).min(1).max(60)}).strict();
export type Composition=z.infer<typeof compositionSchema>;
const registrySchema=z.object({schemaVersion:z.literal(4),version:z.string(),components:z.array(z.object({id:z.string(),description:z.string(),props:z.record(z.string(),z.unknown())})),templates:z.array(z.object({id:z.string(),description:z.string()}))});
export type Registry=z.infer<typeof registrySchema>;
export function validateComposition(raw:unknown,registry:Registry){
 const c=compositionSchema.parse(raw);if(c.registryVersion!==registry.version)throw new AppError(409,'Registry version mismatch; import the matching frontend registry.');
 if(new Set(c.pages.map(p=>p.path)).size!==c.pages.length)throw new AppError(422,'Duplicate page path.');
 for(const p of c.pages){const template=registry.templates.find(t=>t.id===p.template);if(!template)throw new AppError(422,'Unknown template: '+p.template);
 if(p.path.includes(':')&&p.path!=='/wireless/phones/:device')throw new AppError(422,'Only the registered device parameter is supported.');
 if(p.path==='/wireless/phones')throw new AppError(422,'Reserved device namespace.');
 if(new Set(p.blocks.map(b=>b.id)).size!==p.blocks.length)throw new AppError(422,'Each block instance ID must be unique within a page.');
 for(const b of p.blocks){const entry=registry.components.find(c=>c.id===b.component);if(!entry)throw new AppError(422,`Unknown component: ${b.component}`);z.fromJSONSchema(entry.props).parse(b.props);}
 }
 if(new Set(c.surfaces.map(s=>s.id)).size!==2)throw new AppError(422,'Surface IDs must be unique');
 for(const surface of c.surfaces){if(new Set(surface.blocks.map(b=>b.id)).size!==surface.blocks.length)throw new AppError(422,'Duplicate surface instance ID');for(const b of surface.blocks){const entry=registry.components.find(e=>e.id===b.component);if(!entry)throw new AppError(422,'Unknown surface component');z.fromJSONSchema(entry.props).parse(b.props);}}
 return c;
}
export function createRepository(directory:string){
 let queue=Promise.resolve();
 async function json(name:string){return JSON.parse(await readFile(join(directory,name+'.json'),'utf8'));}
 async function registry(){return registrySchema.parse(await json('registry'));}
 async function read(stage:'draft'|'published'){return validateComposition(await json(stage),await registry());}
 async function atomic(name:string,value:unknown){const target=join(directory,name+'.json');const temp=target+'.tmp';await writeFile(temp,JSON.stringify(value,null,2)+'\n');await rename(temp,target);}
 function serial<T>(work:()=>Promise<T>):Promise<T>{const result=queue.then(work);queue=result.then(()=>{},()=>{});return result;}
 async function save(raw:unknown,expected:number){return serial(async()=>{const current=await read('draft');if(current.revision!==expected)throw new AppError(409,'Draft changed. Reload before saving.');const next=validateComposition(raw,await registry());next.revision=current.revision+1;await atomic('draft',next);return next;});}
 async function publish(expected:number){return serial(async()=>{const draft=await read('draft');if(draft.revision!==expected)throw new AppError(409,'Save/reload the current draft before publishing.');await atomic('published',draft);return draft;});}
 async function catalog(){return configSchema.parse({...await json('catalog'),pages:[]});}
 async function compose(path:string,audience:'new'|'existing',stage:'draft'|'published'='published'){
 const composition=await read(stage);const config=await catalog();const normalized=path.replace(/\/$/,'');
 let definition=composition.pages.find(p=>p.path===normalized);let device=null;
 if(!definition){const id=normalized.match(/^\/wireless\/phones\/([^/]+)$/)?.[1];if(id){device=config.devices.find(d=>d.id===id)??null;if(device)definition=composition.pages.find(p=>p.path==='/wireless/phones/:device');}}
 if(!definition)throw new AppError(404,'Page not found.');
 const blocks=definition.blocks.filter(b=>b.audience==='all'||b.audience===audience);
 const resolved=await Promise.all(blocks.map(async b=>{try{return {...b,data:await resolveBlockData(b,config,device,directory)};}catch{return {...b,data:{},error:'This component’s data is temporarily unavailable.'};}}));
 const manifest={path:normalized,template:definition.template,title:definition.title,eyebrow:definition.eyebrow,description:definition.description,requires:definition.requires,sections:blocks.map(b=>b.component),blocks:resolved};
 // Demo business policy: existing customers do not receive the new-customer travel perk.
 if(audience==='existing')config.perks=config.perks.filter(p=>p.id!=='travel');
 return wirelessRendererPropsSchema.parse({config,manifest,device,composition:{revision:composition.revision,registryVersion:composition.registryVersion,audience}});
 }
 return {registry,read,save,publish,catalog,compose};
}
