import {z} from 'zod';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {join} from 'node:path';
import {selectionSchema,surfaceResponseSchema} from './contracts.ts';
import {wirelessQuote} from './business.ts';
import {resolveBlockData} from './resolvers.ts';
import {createRepository,AppError} from './composition.ts';
export const actionSchema=z.object({action:z.enum(['continuePurchase','showCartDetails','continueJourney']),selection:selectionSchema,requestId:z.uuid()}).strict();
export function createJourney(directory:string){
 const repo=createRepository(directory);let queue=Promise.resolve();
 async function execute(cartId:string,raw:unknown,audience:'new'|'existing'){
 if(!/^[a-f0-9-]{36}$/.test(cartId))throw new AppError(400,'Invalid cart session');
 const input=actionSchema.parse(raw);const composition=await repo.read('published');const config=await repo.catalog();if(audience==='existing')config.perks=config.perks.filter(p=>p.id!=='travel');
 const device=config.devices.find(d=>d.id===input.selection.device);if(!device)throw new AppError(422,'Choose a phone first.');
 // Validate device options and extras even before a plan is chosen.
 wirelessQuote({...input.selection,plan:input.selection.plan??'essential'},config);
 const quote=input.selection.plan?wirelessQuote(input.selection,config):null;
 const folder=join(directory,'.runtime');await mkdir(folder,{recursive:true});const file=join(folder,cartId+'.json');
 let previous:any=null;try{previous=JSON.parse(await readFile(file,'utf8'));}catch(e){if((e as NodeJS.ErrnoException).code!=='ENOENT')throw e;}
 const fingerprint=JSON.stringify({action:input.action,selection:input.selection,audience});
 if(previous?.requestId===input.requestId){if(previous.fingerprint!==fingerprint)throw new AppError(409,'Request ID already used with different input');return previous.response;}
 const cart={id:cartId,version:(previous?.response.cart.version??0)+1,selection:input.selection,quote,device};
 const target=input.action==='showCartDetails'?'cart-details':input.action==='continueJourney'?'plan':composition.flows[input.selection.line==='upgrade'?'upgrade':'new'];
 let effect:unknown={type:'navigate',href:'/wireless/plan'};
 if(target!=='plan'){
 const definition=composition.surfaces.find(s=>s.id===target);if(!definition)throw new AppError(422,'Surface is not configured');
 const blocks=await Promise.all(definition.blocks.filter(b=>b.audience==='all'||b.audience===audience).map(async b=>{try{return {...b,data:await resolveBlockData(b,config,device,directory)}}catch{return {...b,data:{},error:'This component is unavailable.'}}}));
 effect={type:'openSurface',surface:{id:definition.id,title:definition.title,blocks}};
 }
 const response=surfaceResponseSchema.parse({cart,effect});const temp=file+'.tmp';await writeFile(temp,JSON.stringify({requestId:input.requestId,fingerprint,response}));await rename(temp,file);return response;
 }
 return {execute(cartId:string,raw:unknown,audience:'new'|'existing'){const result=queue.then(()=>execute(cartId,raw,audience));queue=result.then(()=>{},()=>{});return result;}};
}
