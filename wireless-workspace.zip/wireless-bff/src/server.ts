import {createJourney} from './journey.ts';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
import {timingSafeEqual} from 'node:crypto';
import {z} from 'zod';
import {createRepository,AppError} from './composition.ts';
import {wirelessQuote,validateWirelessOrder} from './business.ts';
const root=dirname(dirname(fileURLToPath(import.meta.url)));
const repo=createRepository(process.env.DATA_DIR??join(root,'data'));
const journey=createJourney(process.env.DATA_DIR??join(root,'data'));
const token=process.env.COMPOSER_TOKEN??'local-composer-demo';
if(process.env.NODE_ENV==='production'&&(!process.env.COMPOSER_TOKEN||token.length<24))throw Error('Configure a strong COMPOSER_TOKEN for production.');
export const server=createServer(async(req,res)=>{
 res.setHeader('Cache-Control','private, no-store');res.setHeader('X-Content-Type-Options','nosniff');
 const send=(status:number,value:unknown)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(value));};
 try{
 const url=new URL(req.url??'/',`http://${req.headers.host}`);const path=url.pathname;
 if(req.method==='GET'&&['/','/composer','/composer.js','/composer.css'].includes(path)){
 const name=path.endsWith('.js')?'composer.js':path.endsWith('.css')?'composer.css':'index.html';res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':'text/html');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'");res.end(await readFile(join(root,'public',name)));return;
 }
 if(req.method==='GET'&&path==='/health'){send(200,{status:'ok',service:'wireless-composition-bff'});return;}
 const audience=req.headers['x-demo-audience']==='existing'?'existing':'new';
 if(path.startsWith('/admin/')){
 const supplied=(req.headers.authorization??'').replace(/^Bearer /,'');const a=Buffer.from(supplied),b=Buffer.from(token);if(a.length!==b.length||!timingSafeEqual(a,b))throw new AppError(401,'Composer token required.');
 if(req.headers.origin&&req.headers.origin!==url.origin)throw new AppError(403,'Cross-origin editor request denied.');
 }
 async function body(){let raw='';for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>256_000)throw new AppError(413,'Request too large.');}try{return JSON.parse(raw)}catch{throw new AppError(400,'Invalid JSON.')}}
 if(req.method==='POST'&&path==='/v1/actions'){send(200,await journey.execute(String(req.headers['x-cart-id']??''),await body(),audience));return;}
 if(req.method==='GET'&&path==='/v1/registry'){send(200,await repo.registry());return;}
 if(req.method==='GET'&&path==='/v1/pages'){send(200,await repo.compose(url.searchParams.get('path')??'/wireless',audience));return;}
 if(req.method==='GET'&&path==='/admin/composition'){send(200,{draft:await repo.read('draft'),published:await repo.read('published'),registry:await repo.registry()});return;}
 if(req.method==='PUT'&&path==='/admin/composition'){const input=z.object({expectedRevision:z.number().int(),composition:z.unknown()}).parse(await body());send(200,await repo.save(input.composition,input.expectedRevision));return;}
 if(req.method==='POST'&&path==='/admin/publish'){const input=z.object({expectedRevision:z.number().int()}).parse(await body());send(200,await repo.publish(input.expectedRevision));return;}
 if(req.method==='GET'&&path==='/admin/preview'){send(200,await repo.compose(url.searchParams.get('path')??'/wireless',url.searchParams.get('audience')==='existing'?'existing':'new','draft'));return;}
 if(req.method==='POST'&&(path==='/v1/quote'||path==='/v1/orders')){
 const config=await repo.catalog();if(audience==='existing')config.perks=config.perks.filter(p=>p.id!=='travel');
 const input=await body();send(200,path==='/v1/quote'?wirelessQuote(input,config):{...validateWirelessOrder(input,config),id:'SIGNAL-DEMO-'+crypto.randomUUID().slice(0,8).toUpperCase()});return;
 }
 throw new AppError(404,'Endpoint not found.');
 }catch(error){if(error instanceof AppError)send(error.status,{error:error.message});else if(error instanceof z.ZodError)send(422,{error:'Validation failed.',issues:error.issues.map(i=>({path:i.path,message:i.message}))});else if(error instanceof Error&&/Choose|Unsupported|Duplicate|Demo|Accept|quote changed/.test(error.message))send(422,{error:error.message});else{console.error('BFF request failed',error instanceof Error?error.name:'UnknownError');send(500,{error:'Unable to process this request.'});}}
});
server.listen(Number(process.env.PORT??4000),'127.0.0.1',()=>console.log('Wireless BFF: http://127.0.0.1:'+(process.env.PORT??4000)+'/composer'));
