import {z} from 'zod';
export const surfaceSchema=z.object({id:z.enum(['quick-cart','cart-details']),title:z.string().min(1).max(140),blocks:z.array(z.object({id:z.string(),component:z.string(),props:z.record(z.string(),z.unknown()),slot:z.enum(['main','sidebar','fullWidth']).default('main'),audience:z.enum(['all','new','existing']).default('all')})).min(1).max(12)});
export const flowSchema=z.object({new:z.enum(['quick-cart','plan']),upgrade:z.enum(['quick-cart','plan'])});
