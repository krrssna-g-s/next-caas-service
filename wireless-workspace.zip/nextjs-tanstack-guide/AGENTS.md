# Project instructions — merge with existing rules

This project uses Next.js App Router, TypeScript, React Compiler, Cache Components, and TanStack Query. Do not introduce Redux/Zustand or recreate the repository.

For new routes, template pages, components, or AI-concierge UI, read `skills/next-template-pages/SKILL.md` and the linked references. After installing the skill, change this path to its actual `.github/skills`, `.cursor/skills`, or `.agents/skills` location.

- Keep server data in the BFF/TanStack ownership model; UI and forms stay local unless genuinely shared.
- Request-scoped deduplication is allowed. Cross-request server data caching is forbidden, including upstream/CDN response caching of personalized data.
- Preserve Cache Components and React Compiler. Runtime reads belong under Suspense; don't add force-dynamic/revalidate/fetchCache segment workarounds.
- Server QueryClients are request-scoped. Browser data is account-scoped and must be cleared/cancelled on identity changes.
- Secrets and auth tokens never enter client props, query keys, hydration, model context, or window debugging APIs.
- Reuse atoms/molecules/organisms across pages and concierge through typed adapters. The concierge has a separate client-safe registry and approved action/tool schemas.
- Never render generated executable code or treat model output as authority for identity, price, consent, or payment.
- Tests: Vitest/Testing Library for contracts and interactions; production-mode integration/E2E for SSR, streaming, hydration, isolation, and full journeys.
- Check installed package versions and local Next documentation before using version-sensitive APIs. Preserve unrelated user changes.

## Updated companion implementation

The regenerated package includes a separate Node BFF, unrestricted component instances, new composed routes, BFF-resolved carousels, and action-driven quick-cart/mini-cart drawers. Read [BFF and surface architecture](skills/next-template-pages/references/bff-and-surfaces.md) and the sibling [BFF setup guide](../wireless-bff/SETUP.md). The skill folder remains self-contained when installed; the sibling BFF guide belongs to the full source bundle.
