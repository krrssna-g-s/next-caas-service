# Separate UI monorepo and a language-neutral component registry

This guide describes the target setup for your work machine. The delivered local app remains a runnable reference; this documentation does not claim that private packages or remote repositories have been created or published.

## Repository layout

```text
private-atoms/                 Existing repository and private package
shared-ui/                     New or existing independent monorepo
  packages/
    atom-adapters/
    molecules/
    organisms/
    design-tokens/
    component-contracts/       Schemas/metadata only; no React imports
  scripts/
    generate-registry.ts
  pnpm-workspace.yaml
  package.json
storefront/                    Existing independent Next.js repository
composition-bff/               Independent Node.js POC repository
```

React implementations and metadata travel through separate dependency paths:

```text
Private atoms → UI adapters → molecules/organisms → Next.js build
                                    │
                           reviewed component schemas
                                    ↓
                          package release generation
                                    ↓
                   immutable registry.json + schemas
                             ↙             ↘
                   Node BFF now      Spring Boot later
```

## 1. Initialize the UI workspace

Use your company's approved Node/pnpm versions and private-registry setup. Preserve an existing monorepo instead of reinitializing it. For an empty directory:

```sh
mkdir shared-ui
cd shared-ui
pnpm init
mkdir -p packages/atom-adapters packages/molecules packages/organisms packages/design-tokens packages/component-contracts scripts
pnpm add -Dw typescript tsx vitest @types/node @types/react @types/react-dom @changesets/cli
```

Make the root package private. Add an exact approved `packageManager` version. Create `pnpm-workspace.yaml`:

```yaml
packages:
  - 'packages/*'
```

Give every package its own package.json, source, tsconfig, test/build commands and explicit exports. Start with TypeScript project builds or your established bundler; Turborepo is optional and only orchestrates tasks. The snippets below assume packages export compiled ESM plus declarations. Preserve JSX client directives in the chosen build.

Inside the UI monorepo, use `workspace:*` for local package dependencies. When packing/publishing with pnpm these become package-version references. Next and BFF, in separate repositories, must install published versions or packed tarballs—not unresolved workspace links. [pnpm workspaces](https://pnpm.io/workspaces)

Install the approved private atom package into atom-adapters using its real name and version. Do not invent exports. Wrap only what needs adaptation; consume supported tokens and accessibility APIs. Keep React/React DOM as compatible peer dependencies of UI packages and external to their build output. If hooks cross package boundaries, align TanStack Query versions and reuse the app provider.

## 2. Define accepted configuration explicitly

Do not try to serialize an arbitrary React props interface. A component has three distinct inputs:

| Input | Example | Registry treatment |
|---|---|---|
| Author configuration | title, collection, density | propsSchema |
| BFF-resolved data | slides, quote rows | dataSchema |
| Runtime bindings | onSelect callback, ref, React children | Named events/adapters; never serialized functions |

For every composable component, define reviewed schemas next to metadata in component-contracts. Use either JSON Schema as the source or Zod 4 constrained to JSON-representable types. Example schema authoring:

```ts
import {z} from 'zod';

export const carouselProps = z.object({
  title: z.string().min(1).max(140).describe('Visible carousel heading'),
  collection: z.enum(['checkout-offers', 'phone-highlights'])
    .describe('Approved BFF media collection'),
  showCaptions: z.boolean().optional()
}).strict();

export const carouselData = z.object({
  slides: z.array(z.object({
    src: z.string().min(1),
    alt: z.string(),
    caption: z.string().optional()
  }).strict()).min(1).max(12)
}).strict();

export type CarouselConfig = z.infer<typeof carouselProps>;
export type CarouselData = z.infer<typeof carouselData>;
```

Use these types in the component's serializable props. Runtime callbacks are separate typed props provided by its adapter. Maintain behavioral defaults in code and test them against editor defaults: JSON Schema `default` is an annotation, not a requirement that every validator inserts a value. URL policy and other domain constraints must also be enforced by resolvers.

Zod can emit JSON Schema with `z.toJSONSchema`. Unsupported JS types/transforms must fail export; do not use `unrepresentable: 'any'` to silently weaken the contract. [Zod JSON Schema](https://zod.dev/json-schema)

If your private atom package only exposes `.d.ts`, inspect/document it and author a reviewed JSON-safe adapter contract. Type/docgen tools can assist with discovery, but cannot infer all runtime constraints or safely expose function-valued props. The generated registry describes accepted **composition props**, not every internal React prop.

## 3. Generate component metadata during release build

Maintain an explicit list of component definitions. Do not import the React renderer or crawl arbitrary modules to discover names. Example generator logic, to integrate into `scripts/generate-registry.ts`:

```ts
import {z} from 'zod';
import {readFile, mkdir, writeFile} from 'node:fs/promises';
import {carouselProps, carouselData} from '../packages/component-contracts/src/carousel';

const pkg = JSON.parse(await readFile(
  new URL('../packages/organisms/package.json', import.meta.url), 'utf8'
));
const manifest = {
  schemaVersion: 1,
  package: {name: pkg.name, version: pkg.version},
  components: [{
    id: 'imageCarousel',
    displayName: 'Image carousel',
    description: 'Reusable gallery from a named media collection',
    contractVersion: '1.0.0',
    exportPath: `${pkg.name}/image-carousel`,
    rendering: 'client',
    propsSchema: z.toJSONSchema(carouselProps, {target: 'draft-2020-12'}),
    dataSchema: z.toJSONSchema(carouselData, {target: 'draft-2020-12'}),
    events: [],
    editorDefaults: {
      title: 'Explore', collection: 'checkout-offers', showCaptions: true
    }
  }]
};
const output = new URL('../packages/organisms/dist/', import.meta.url);
await mkdir(output, {recursive: true});
await writeFile(new URL('component-registry.json', output),
  JSON.stringify(manifest, null, 2) + '\n');
```

Install Zod 4 as a development dependency in the workspace for this example. For multiple packages, drive this from explicit definitions for each owning package and read each package's release version from its package.json. Sort components/schema keys deterministically before calculating the release digest. Do not embed changing timestamps in the hashed payload.

A generated propsSchema contains `properties`, `required`, `type`, enums and constraints. This is what the composer uses to know the accepted inputs. For example:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "title": {"type": "string", "minLength": 1, "maxLength": 140},
    "collection": {"type": "string", "enum": ["checkout-offers", "phone-highlights"]},
    "showCaptions": {"type": "boolean"}
  },
  "required": ["title", "collection"],
  "additionalProperties": false
}
```

## 4. Include registry metadata in the published package

Relevant package.json fields for the organisms package:

```json
{
  "name": "@company/organisms",
  "version": "1.0.0",
  "type": "module",
  "files": ["dist"],
  "exports": {
    "./image-carousel": {
      "types": "./dist/image-carousel.d.ts",
      "import": "./dist/image-carousel.js"
    },
    "./registry.json": "./dist/component-registry.json"
  },
  "sideEffects": ["**/*.css"],
  "scripts": {
    "build": "tsc -p tsconfig.build.json",
    "registry:generate": "tsx ../../scripts/generate-registry.ts",
    "prepack": "pnpm run build && pnpm run registry:generate"
  }
}
```

This is a package configuration excerpt; add real dependencies/peer ranges and tsconfig paths matching your source/build. Only declare sideEffects this narrowly if the package really has no other required import-time effects. Preserve CSS asset copying and client directives in build outputs. Do not make `build` call `pack`, which would recurse through prepack.

The lifecycle generates registry information **before** the package is packed/published, so the code and schema are in the same immutable release. It is not generated after users install the package. CI must also run the generation explicitly and inspect the tarball, because lifecycle scripts may be disabled by policy. [npm lifecycle scripts](https://docs.npmjs.com/cli/using-npm/scripts)

Local verification, without publishing:

```sh
pnpm install
pnpm -r run build
# Run each package's tests and generation scripts as configured.
cd packages/organisms
pnpm pack
```

Inspect the resulting tarball: it must include the React export, declarations, necessary CSS and component-registry.json. Install the exact tarball in a separate consumer fixture and test its public exports. Linked-source tests alone can hide missing packed files.

Use Changesets or your existing release mechanism to apply final package versions before generation. Publish only from authorized CI/user workflows. Credentials come from the approved registry/OIDC integration, not source control.

## 5. Expose a language-neutral aggregate registry

A release pipeline aggregates exact per-package manifests into a registry release:

```text
registry/releases/ui-2026-11-17.1/
  registry.json
  schemas/...
  openapi.yaml
  fixtures/valid/...
  fixtures/invalid/...
  SHA256SUMS
```

The example release name is illustrative. Store exact UI package versions and component contract versions in registry.json. Generate the digest after schema bundling and compare it during deployment. OpenAPI describes the HTTP page/action/error contracts; it does not replace the individual component schemas.

Expose these static artifacts in an authenticated artifact repository your Java and Node environments can access. Node can consume a metadata-only npm package or download the JSON artifact during deployment. Spring Boot later consumes those SAME JSON files and validates them with its selected 2020-12-compatible validator. No Node runtime is required in Java services.

For the local POC, copying the generated immutable artifact to the BFF's configured registry directory is sufficient. BFF `GET /v1/registry` can expose the pinned registry to the authenticated business composer. Do not import React to serve that endpoint. The existing sample's embedded registry format needs a versioned adapter/migration to adopt this richer manifest; do not overwrite it blindly.

Choose JSON Schema draft 2020-12 and document $ref resolution, formats, unknown-field handling, nullability, number limits and default behavior. Bundle references or resolve only trusted artifact-local references. Run positive/negative fixtures through Ajv2020 now and the selected Java validator when Spring Boot is introduced. Types alone are not runtime validation.

## 6. Coordinate adoption across separate repositories

```text
Version source → build → generate schemas → validate → pack
       → publish UI packages and immutable registry artifacts
       → upgrade pinned package versions in Next.js
       → deploy frontend with a capability manifest
       → activate matching BFF registry/composer capabilities
       → publish compositions using new components
```

A published component package is not automatically present in a deployed frontend. Track the exact registry release/package versions that a frontend deployment supports; the composer/BFF must reject configurations targeting unavailable contracts. During rolling deployments keep compatible contracts or route traffic by deployment capability. A shared repository alone would not remove this deployment concern either.

In Next.js import explicit subpaths, e.g. `@company/organisms/image-carousel`, through a code-owned renderer map. Metadata exportPath is informative; it is not permission to dynamically import arbitrary strings from BFF JSON. Use explicit lazy imports for suitable large client blocks. Do not ship the entire authoring registry to browsers if only a minimal runtime map is needed.

Production business configuration remains unrestricted across templates within the deployed registered component set. Unknown components, unsafe values and incompatible versions must still be rejected.

## 7. Required checks

- Deterministic registry generation and package/version alignment.
- Duplicate component/instance IDs rejected.
- Required, optional, enum, unknown and invalid property examples validated.
- Serializable component TypeScript props derive from the authoritative schema.
- Private atoms are consumed without copying implementation.
- Packed exports, CSS, client directives and React peers verified.
- Per-package schemas match the aggregated release/digest.
- Old frontend cannot receive a new unsupported component contract.
- Node BFF validates without importing React.
- Existing composition, action, drawer and business-rule tests continue passing.

Build/registry artifact reuse does not permit caching personalized BFF responses. Retain no-store for runtime user data and request-scoped deduplication only.
