# Work-machine implementation prompt — separate repositories

Replace bracketed inputs, then give this prompt and the companion MONOREPO-REGISTRY-SETUP.md to your coding assistant. This instructs an implementation; it does not imply that the existing local sample has already been split into published packages.

```text
Implement or adapt the wireless composition POC using THREE SEPARATE
repositories. Do not move Next.js into the UI monorepo or merge repositories.

INPUTS
- Next.js application repository: [PATH]
- Shared UI monorepo: [PATH, OR CREATE A NEW REPOSITORY]
- Node.js POC BFF repository: [PATH, OR CREATE A NEW REPOSITORY]
- Existing POC source bundle: [PATH, OR NOT AVAILABLE]
- Private atom package(s) and approved versions: [NAMES/VERSIONS]
- Private atom documentation/examples: [PATHS]
- Private npm registry: [URL]
- Language-neutral artifact repository: [URL/TYPE, OR LOCAL POC DIRECTORY]
- Package manager: [EXISTING CHOICE, OR PNPM FOR THE NEW UI MONOREPO]
- Approved Node.js version: [VERSION]

Inspect existing instructions, code, installed versions, lockfiles and auth
before editing. Adapt the supplied POC if available. Keep working apps intact.
Use existing private-registry authentication. Never request secrets in chat,
commit tokens, invent private package exports, or publish without explicit
release authorization. Build and pack locally to make changes reviewable.

BACKEND CHOICE
Implement the POC BFF in Node.js/TypeScript only. Do not implement Spring Boot
in this task. Production BFF and domain services will later be Spring Boot,
so HTTP contracts and registry artifacts must be language-neutral.

REPOSITORY BOUNDARIES
1. Private atoms remain in their existing repository and are consumed as
   approved versioned packages. Never duplicate their implementations.
2. Shared UI monorepo contains atom-adapters, molecules, organisms/commerce
   blocks, design tokens and a metadata-only component-contracts package.
3. Existing Next.js app consumes published UI packages at pinned versions.
   For local POC work, install packed tarballs; workspace: dependencies apply
   within the UI monorepo, not across unrelated repositories.
4. Node BFF consumes versioned JSON contracts/registry artifacts, not React
   implementations. It remains independently runnable/deployable.

REGISTRY AND CONTRACT GENERATION
Use an explicit, reviewed serializable contract for every composable block.
Follow the companion MONOREPO-REGISTRY-SETUP.md.

Generate JSON Schema draft 2020-12 for author-editable props and BFF-resolved
component data. Include component ID, display name, description, contract
version, npm package name/version, public export path, rendering capability,
accepted props (required/optional/type/enum/constraints/descriptions), data
schema, supported declarative events and editor defaults where appropriate.

Do not claim arbitrary TypeScript/React props can all be converted to JSON.
Exclude ReactNode, functions, refs, class instances, hooks and secrets from
public configuration. Represent action bindings as validated names; bind
callbacks inside Next. Document the internal runtime props separately.
Type extraction/docgen may produce documentation or draft schemas, but is
not the authority for runtime validation.

Use schema-first definitions and derive serializable TypeScript types from
those schemas. Runtime callbacks are a separate adapter concern. Test that
components and published schemas stay aligned. Reject unrepresentable
schemas, duplicate component IDs, invalid examples, missing exports and
inconsistent versions. Never silently widen unsupported schema types to any.

RELEASE PIPELINE
After applying release versions, build UI packages and generate each
package's component manifest and JSON schemas BEFORE packing/publishing.
Include these artifacts in the same npm tarball as the relevant UI code.
Verify the actual tarball file list and exported paths.

Aggregate exact package manifests into an immutable registry release with
exact package versions, contract versions and a SHA-256 digest. Distribute
plain JSON/schema files through an approved artifact repository so Spring
Boot can download them without npm or TypeScript. Node may consume the same
files or a metadata-only npm artifact.

Use release-build/prepack integration and explicit CI checks. Do not rely
on consumer postinstall hooks, live React reflection, arbitrary filesystem
scanning, or importing all React modules to discover metadata. Prevent stale
artifacts when lifecycle scripts are disabled. Do not publish from this task
without explicit user authorization.

Record a frontend capability manifest containing the package versions,
registry release and component contracts included in that deployment.
A package publish makes a component available for adoption, not instantly
available on an older frontend. Gate business publication against the
active frontend deployment's capabilities. Pin immutable registry releases;
do not fetch a mutable latest registry on each user request.

Use OpenAPI 3.1 for page/action/cart/error HTTP contracts and JSON Schema
2020-12 for component definitions. Validate schemas and shared positive and
negative payload fixtures with a standards-compatible Node validator such
as Ajv2020. Specify the draft, format enforcement and $ref resolution policy
so future Java validators can implement the same behavior. No remote $ref
fetching from business-authored configuration.

COMPOSITION AND JOURNEYS
Support any registered component in any template, repeated instances,
unique IDs, main/sidebar/fullWidth slots and independent data/error states.
No per-template component allowlists. Require safe registered code and
valid props/data. Do not execute HTML, JS or imports supplied by JSON.

Build a business composer with new /wireless/... pages, block configuration,
reordering/removal, audience targeting, separate drafts/published versions,
preview and optimistic revision checks. Publishing existing components or
new composed pages must not require rebuilding Next. New implementations
still require a compatible UI package and frontend deployment.

Implement the fictional wireless journey:
catalog → device → plan → trade-in → extras → cart → checkout → confirmation.
Include shipping, test payment categories, disclosures and agreements.
Reuse the private atoms through adapters and monorepo molecules/organisms.

Support page and drawer compositions. Device Next steps triggers an approved
BFF action. New-line flow opens quick-cart; another flow navigates directly.
Mini-cart summary on later pages opens Details with monthly/one-time charges,
credits and totals. The BFF returns authoritative cart/quote plus an effect:
openSurface or navigate. One accessible client drawer host renders its blocks.
Business users configure approved flow outcomes and surface contents.

BFF owns composition/orchestration. Domain adapters own authoritative cart,
pricing, inventory, eligibility and order behavior; keep these replaceable
by Spring Boot domain-service calls later. Never encode business authority
in React props or trust browser eligibility/price values.

STATE, RENDERING AND CACHING
Retain TanStack Query; do not add Redux/Zustand. Local UI/form drafts remain
local. Use action mutations, current-cart versions and matching quote keys.
Prevent stale responses and duplicate submissions. Use durable idempotency
and ownership checks for real persisted transactions; clearly identify any
POC substitute. No real purchase, payment or subscription should occur.

Keep React Compiler and Cache Components enabled. Runtime reads belong
under Suspense. No cross-request server data/response caches; request-local
deduplication is allowed. Personalized fetches/responses use no-store.
Static assets, released registry metadata and compiled build artifacts are
separate from personalized response caching.

Server QueryClients are request-scoped; browser providers have explicit
identity lifetimes. An SSR cart needs an authorized server read and hydration,
not sessionStorage. Use existing auth if available; otherwise document demo
identity and do not claim production authentication. Provide only sanitized,
read-only development state inspection.

Keep Server Components/server-only imports out of client registries.
Preserve use client directives in built packages. Use explicit subpath
exports and lazy imports for heavy interactive blocks. Externalize React
and React DOM; align shared TanStack context/runtime versions. Do not ship
private-registry credentials or full authoring metadata to the browser.

TESTS AND DELIVERY
Use Vitest/Testing Library for new packages; preserve established app test
conventions. Include artifact/contract tests, missing/invalid props,
unknown components, every-template placement, repeated instances,
new-route publication, failed resolvers, stale revisions, session isolation,
action outcomes, retries, summary/detail consistency and keyboard behavior.
Run production-mode SSR/hydration and browser journey checks. Inspect actual
bundle output; do not invent performance improvements.

Provide setup docs for EACH repository, private atom integration, local
package packing/installation, registry generation and exposure, release and
rollback order, BFF setup, composer usage, diagrams, errors and testing.
Update AGENTS.md and the existing reusable skill with links to these rules;
avoid duplicating full instructions into every editor configuration.

Run build/type checks/tests, pack without publishing, verify generated
contracts and tarballs, and provide a clean source bundle excluding secrets,
dependencies, build output and runtime cart/customer state. Clearly separate
implemented features, illustrative snippets and future production work.
```
