# Setup in an existing Next.js repository

## 1. Inspect and preserve

Use the repo's package manager and lockfile. Confirm installed Next.js, React, TanStack Query, TypeScript, app directory (`app` vs `src/app`), authentication, BFF client, aliases, styling, and test tools. Examples below use `src/` and `@/*` → `src/*`. Adapt imports if the repo differs.

Do not recreate the app. Do not overwrite root layouts, providers, next.config, AGENTS.md, or scripts. Merge deliberately.

## 2. Dependencies

This guide uses TanStack Query **v5 APIs**. Retain compatible installed versions; check peer dependencies before installation. The existing Next/React pair should remain unchanged unless a separately justified upgrade is requested.

```sh
# Runtime: add only missing packages
npm install @tanstack/react-query@5 zod react-hook-form @hookform/resolvers react-error-boundary server-only

# Development and testing
npm install -D @tanstack/react-query-devtools@5 vitest @vitest/coverage-v8 vite @vitejs/plugin-react vite-tsconfig-paths jsdom @testing-library/react @testing-library/dom @testing-library/jest-dom @testing-library/user-event @playwright/test msw

# Only if the existing React Compiler setup needs this package
npm install -D babel-plugin-react-compiler

# For E2E execution; run in your authorized development/CI environment
npx playwright install chromium
```

Match `@vitest/coverage-v8` to the installed Vitest version. Match Query Devtools to Query's major version. Commit the lockfile and use `npm ci` in CI. Check Node requirements for all selected versions instead of relying only on Next.js's minimum.

| Package | Purpose |
| --- | --- |
| TanStack Query | Browser query lifecycle, mutations, hydration, request-local SSR query data |
| Zod | Runtime validation of BFF responses, page manifests, and mutation inputs |
| React Hook Form + resolvers | Local form drafts and validation |
| react-error-boundary | Client component render boundaries and reset integration |
| server-only | Prevent server data/auth modules from entering client bundles |
| Vitest + Testing Library | Domain, contract, state ownership, interaction and component tests |
| MSW | API simulation for client tests without mocking Query internals |
| Playwright | Browser journeys, hydration, streaming, and isolation against a real server |

No Redux, Zustand, or persistent-query-cache plugin is required. Do not put local form fields into the query cache.

## 3. Preserve Next.js features

Merge into `next.config.ts`:

```ts
import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactCompiler: true,
  cacheComponents: true,
  experimental: {
    // Merge with existing experimental options.
    serverComponentsHmrCache: false,
  },
};
export default nextConfig;
```

`serverComponentsHmrCache` is version-sensitive/experimental; verify support in the installed version. Its purpose is to prevent development HMR from retaining fetch results, even no-store results. Production behavior must be tested separately.

Do not add segment exports for `dynamic`, `fetchCache`, or `revalidate` to personalized routes under Cache Components. Leave the feature enabled, move runtime work under Suspense, and opt no data loaders into cross-request caching. A static shell with no business/user data is compatible with this policy.

## 4. Suggested structure

```text
src/
  app/
    providers.tsx
    layout.tsx
    error.tsx
    global-error.tsx
    not-found.tsx
    experience/[[...slug]]/page.tsx
    experience/loading.tsx
    experience/error.tsx
    cart/page.tsx                     # explicit specialized route
    api/cart/route.ts                 # authenticated browser API
  components/
    atoms/button.tsx
    molecules/field.tsx
    organisms/order-summary.tsx
    feedback/component-boundary.tsx
  features/
    template-engine/schema.ts
    template-engine/renderer.tsx
    template-engine/templates.tsx
    cart/contracts.ts
    cart/query-keys.ts
    cart/client-queries.ts
    cart/cart-panel.tsx
    checkout/                        # workflow + form state
  lib/
    query/make-query-client.ts
    query/server-query-client.ts
    query/browser-query-provider.tsx
    query/dev-inspector.tsx
    server/auth.ts                   # existing trusted implementation
    server/bff.ts
    server/cart.ts
    errors.ts
  test/setup.ts
  test/server-only-stub.ts
  test/unit/
  test/components/
  test/integration/
tests/e2e/
vitest.config.mts
playwright.config.ts
```

Keep provider placement as narrow as the domain requires. A root provider is reasonable when authenticated server data is shared broadly; a journey provider is reasonable for bounded purchase workflows. Do not create a new browser QueryClient in every atom or route component.

## 5. Installation sequence

1. Add missing packages and merge configuration.
2. Implement the BFF/auth boundary and typed DTO schemas first.
3. Add shared query keys, the request-local server client, and the browser provider.
4. Build one personalized SSR page with hydration before adding the template registry.
5. Add the manifest parser, templates, and one approved page-level block.
6. Add route/global/component errors, form validation, and mutation recovery.
7. Add the development inspector with an explicit allowlist of inspectable data.
8. Run unit/component tests, typecheck, build, and production-mode two-user integration/E2E tests.
9. Expand only after the first vertical slice passes.

Use existing observability, auth, design tokens, and backend contracts. The guide deliberately does not generate placeholder production credentials or an authentication bypass.

## Sources

- [Next.js Cache Components migration](https://nextjs.org/docs/app/guides/migrating-to-cache-components)
- [HMR fetch cache](https://nextjs.org/docs/app/api-reference/config/next-config-js/serverComponentsHmrCache)
- [Next.js Vitest setup](https://nextjs.org/docs/app/guides/testing/vitest)

## Companion app update

See [BFF and surfaces](bff-and-surfaces.md) for the implemented action/composition boundary. This guide describes production setup patterns (including Vitest and SSR hydration); the runnable demo retains its Node test runner, browser selection draft, latest server cart snapshots, and simulated orders. Do not infer an implemented model endpoint, production authentication, SSR cart restore or durable payment idempotency from these examples.
