# State, SSR, hydration, and cache policy

Examples target TanStack Query v5. Named domain functions such as `requireSession`, DTO schemas, and telemetry are application integration points, not built-in library APIs.

## Ownership

| State | Owner |
| --- | --- |
| Cart, quotes, eligibility, catalog, persisted preferences | Backend, represented in TanStack Query |
| Modal, expanded card, local selection | useState / useReducer |
| Shipping/form drafts | React Hook Form |
| Bookmarkable filters, sort, route identity | URL |
| Unsaved cross-step workflow | Journey-scoped reducer/context when actually needed |
| Concierge-rendered cart/product data | The same query keys/provider as the surrounding page |

Do not mirror query results into another global store. A form draft is an intentional copy with an explicit save/reset/conflict policy.

## Cache contract

Allowed: request-local React memoization, request-local TanStack cache/deduplication, and browser-memory TanStack cache. Forbidden: application data reused across server requests through Next Data Cache, use cache, unstable_cache, ISR, a process-global store/Map, Redis response cache, CDN, or proxy cache.

Request-local state necessarily lives in memory while rendering. It is not durable state. React `cache()` is scoped to the server render; it does not mean the whole HTTP lifecycle, route handlers, Server Actions, prefetches, and later navigations share one cache. Parallel route slots can share it when they participate in the same render and import the same memoized function with matching arguments.

Use primitive canonical arguments. Two newly created object arguments are not necessarily the same React memoization key. Never build module-level Maps keyed by request/session to emulate this scope.

## Request-scoped BFF loader

```ts
// src/lib/server/cart.ts
import 'server-only';
import { cache } from 'react';
import { requireSession } from './auth';
import { cartSchema } from '@/features/cart/contracts';

export const getCartForRequest = cache(async (cartId: string) => {
  const session = await requireSession();
  // requireSession must validate the session, not trust a client userId.
  const response = await fetch(
    `${process.env.BFF_URL}/carts/${encodeURIComponent(cartId)}`,
    {
      cache: 'no-store',
      redirect: 'error',
      headers: {
        Authorization: `Bearer ${session.accessToken}`,
        'Cache-Control': 'no-store',
      },
      signal: AbortSignal.timeout(8_000),
    },
  );
  // Map status to typed application errors in your real BFF adapter.
  // Never expose raw upstream bodies, tokens, or internal URLs to users.
  if (!response.ok) throw new Error('Unable to load cart');
  return cartSchema.parse(await response.json());
});
```

The explicit signal may prevent automatic fetch memoization; the outer React cache supplies intentional request deduplication. Treat BFF_URL as a trusted server-only origin. Use existing auth, typed error mapping, allowlisted headers, timeouts, and schema validation. Do not log authorization headers or payloads.

## Server QueryClient and browser QueryClient

```ts
// src/lib/query/make-query-client.ts
import { QueryClient } from '@tanstack/react-query';

export function makeQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { staleTime: 30_000, retry: false },
      mutations: { retry: false },
    },
  });
}
```

`staleTime` is an example browser freshness policy, not a Next.js cross-request cache TTL. Set it per domain: a quote may need stricter freshness than product descriptions. On the server the QueryClient must be discarded with its request, regardless of staleTime. Avoid server gcTime timers; the server default is suitable for request-local clients. Do not set `gcTime: 0` before dehydration.

```ts
// src/lib/query/server-query-client.ts
import 'server-only';
import { cache } from 'react';
import { makeQueryClient } from './make-query-client';

export const getServerQueryClient = cache(makeQueryClient);
```

```tsx
// src/lib/query/browser-query-provider.tsx
'use client';
import { QueryClientProvider, type QueryClient } from '@tanstack/react-query';
import { makeQueryClient } from './make-query-client';

let browserClient: QueryClient | undefined;
function getClient() {
  // Never retain a module-level QueryClient on the server.
  if (typeof window === 'undefined') return makeQueryClient();
  return (browserClient ??= makeQueryClient());
}

export function QueryProvider({ children }: { children: React.ReactNode }) {
  return <QueryClientProvider client={getClient()}>{children}</QueryClientProvider>;
}
```

This browser singleton assumes one authenticated application scope per browser runtime. Use an instance-scoped provider if the app hosts multiple independent roots. On account switch/logout: block old UI, cancel old queries, clear the query and mutation caches, reset forms/journey state/concierge transcript, then render the new scope. Avoid late results from non-abortable old requests repopulating new state: separate identities in keys and enforce a scope-change barrier or replace the client. Do not put raw access tokens in keys.

## Query keys and selective hydration

```ts
export const cartKeys = {
  detail: (scopeKey: string, cartId: string) =>
    ['cart', scopeKey, cartId] as const,
};
```

`scopeKey` is an opaque non-secret identifier for the authenticated account/tenant context, derived server-side. It prevents accidental browser cache collisions; it is not authorization. The backend must check cart ownership independently.

```tsx
// src/app/cart/page.tsx — explicit route, same pattern for a catch-all
import { Suspense } from 'react';
import { dehydrate, HydrationBoundary } from '@tanstack/react-query';
import { getServerQueryClient } from '@/lib/query/server-query-client';
import { getCartForRequest } from '@/lib/server/cart';
import { requireSession } from '@/lib/server/auth';
import { cartKeys } from '@/features/cart/query-keys';
import { CartPanel } from '@/features/cart/cart-panel';

export default function Page() {
  return <Suspense fallback={<p role="status">Loading your cart…</p>}>
    <RequestCart />
  </Suspense>;
}

async function RequestCart() {
  const session = await requireSession(); // reads request cookies
  const client = getServerQueryClient();
  const key = cartKeys.detail(session.scopeKey, session.cartId);
  // fetchQuery propagates mandatory-data failures. prefetchQuery does not.
  await client.fetchQuery({
    queryKey: key,
    queryFn: () => getCartForRequest(session.cartId),
  });
  return <HydrationBoundary state={dehydrate(client, {
    shouldDehydrateQuery: q => q.state.status === 'success'
      && q.queryKey[0] === 'cart'
      && q.queryKey[1] === session.scopeKey
      && q.queryKey[2] === session.cartId,
  })}>
    <CartPanel scopeKey={session.scopeKey} cartId={session.cartId} />
  </HydrationBoundary>;
}
```

The provider must already wrap this subtree. Only send an allowlisted public cart DTO to hydration: every field is browser-visible. Do not manually inject JSON into a script tag; let HydrationBoundary/React handle serialization. Do not dehydrate the entire request QueryClient just because unrelated parallel slots populated it.

```tsx
// src/features/cart/cart-panel.tsx
'use client';
import { useQuery } from '@tanstack/react-query';
import { cartKeys } from './query-keys';
import { cartSchema } from './contracts';

export function CartPanel({scopeKey, cartId}: {scopeKey: string; cartId: string}) {
  const query = useQuery({
    queryKey: cartKeys.detail(scopeKey, cartId),
    queryFn: async ({ signal }) => {
      const response = await fetch(`/api/cart?id=${encodeURIComponent(cartId)}`, {
        signal, cache: 'no-store', credentials: 'same-origin',
      });
      if (!response.ok) throw new Error('Unable to refresh cart');
      return cartSchema.parse(await response.json());
    },
  });
  if (query.isPending) return <p role="status">Loading cart…</p>;
  if (query.isError && !query.data) return <div role="alert">
    Cart unavailable. <button onClick={() => query.refetch()}>Retry</button>
  </div>;
  if (!query.data) return null;
  return <section>
    {query.isError && <p role="status">Refresh failed; showing the previous cart.</p>}
    <h2>Your cart</h2>
    {/* Render validated DTO with presentational components. */}
  </section>;
}
```

Client query functions use same-origin APIs/RPC, not Server Actions for reads. APIs independently authenticate, validate inputs, authorize ownership, and call server services. Successful and error responses for personalized APIs use `Cache-Control: private, no-store`. Prevent intermediary caching at the deployment layer; headers on an upstream fetch alone do not control your HTML/RSC response.

## Server and client consumption

Server Components may read the DTO returned by the memoized loader or fetchQuery and use shared pure selectors. They do not use client hooks. Client Components use the matching query key, including during SSR, then hydrate from the same snapshot.

Do not render a mutable total both as a Server Component and as client-owned query output unless you implement synchronization. Client refetching cannot rerender an already-produced Server Component. Prefer client ownership of that entire mutable display, or explicitly router.refresh after mutations that affect server-rendered views.

A request-scoped snapshot is not a shared mutable store across parallel slots. Parallel server components must not depend on each other mutating a QueryClient to drive rendering order.

## Mutations and revisions

Use `useMutation` for explicit actions. Include expected version/revision for optimistic concurrency; the backend recomputes totals and returns a fresh authoritative DTO. On success, update the exact query key with the returned snapshot and invalidate related keys as appropriate. Refresh RSC-owned output when required. Invalidating React Query does not invalidate/re-render Server Components by itself.

For optimistic updates: cancel affected reads, snapshot previous data, apply the optimistic change, roll back on failure, reconcile on success, and handle overlapping mutations. Money, inventory, consent, and eligibility need authoritative confirmation. Payment/order creation must use backend idempotency, not UI button disabling alone. Do not automatically retry an uncertain payment result.

## Streaming and route parameters

Keep request `params`, `searchParams`, cookies, headers, and runtime BFF operations inside an async child below Suspense. Use connection() inside that child only when request-time behavior is required without another request API; do not use it to skip authentication. Static metadata is simplest; personalized metadata must not fetch outside the route's supported runtime structure or expose private information.

Use independent Suspense boundaries for optional sections. Start independent operations together, but don't await all of them at the page root. For required groups, await as a group within their boundary. Priority labels describe UX importance, not a guaranteed network/reveal ordering.

## Browser inspection

TanStack Query Devtools is the primary query/mutation inspector. A development-only `window.__APP_STATE__` helper should return **sanitized snapshots**, never the live QueryClient, mutation variables, raw API errors, credentials, or functions that mutate state.

```tsx
'use client';
import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';

type Inspector = {
  queries: () => unknown[];
  query: (key: readonly unknown[]) => unknown;
  mutations: () => unknown[];
};
declare global { interface Window { __APP_STATE__?: Inspector } }

export function DevInspector() {
  const client = useQueryClient();
  useEffect(() => {
    if (process.env.NODE_ENV !== 'development') return;
    // Implement a domain-specific allowlist of fields; default to nothing.
    const safeData = (key: readonly unknown[], data: unknown): unknown => {
      // Example: return only public product IDs / non-sensitive totals
      // after schema validation. Do not return data unconditionally.
      return { redacted: true };
    };
    const inspector: Inspector = {
      queries: () => client.getQueryCache().getAll().map(q => ({
        // Keys must themselves contain no secrets or PII.
        key: structuredClone(q.queryKey),
        status: q.state.status,
        fetchStatus: q.state.fetchStatus,
        updatedAt: q.state.dataUpdatedAt,
        data: safeData(q.queryKey, q.state.data),
      })),
      query: key => safeData(key, client.getQueryData(key)),
      mutations: () => client.getMutationCache().getAll().map(m => ({
        status: m.state.status, submittedAt: m.state.submittedAt,
      })),
    };
    window.__APP_STATE__ = inspector;
    return () => {
      if (window.__APP_STATE__ === inspector) delete window.__APP_STATE__;
    };
  }, [client]);
  return null;
}
```

Mount under QueryProvider only in development. Configure safeData to expose approved fields before expecting query contents. React DevTools inspects local component state; that state does not automatically appear in Query's cache. Scope any additional journey inspector similarly. Never use this window API as an application integration mechanism or as the concierge's data source.

## Deployment verification

- No data loaders use persistent cache directives, positive revalidation, or external response caches.
- Disable development HMR fetch retention where supported.
- BFF/SDK/ORM must not secretly cache user results across requests; database persistence and connection pooling are not response caching.
- Shared CDN/proxy rules bypass personalized document, RSC, and API responses. Preserve Next.js routing/Vary headers.
- Inspect actual production responses, including navigation/prefetch and authenticated error responses. Next may control page headers; don't assume a blanket next.config header override wins.
- Test A then B, concurrently and sequentially, using the same URL. Verify distinct data and renewed upstream calls across requests.
- Browser Query/Router caches are separate from server caches. Disable eager prefetch where appropriate, but do not describe that as a server cache fix.

## Sources

- [TanStack SSR](https://tanstack.com/query/v5/docs/framework/react/guides/advanced-ssr)
- [Next.js fetching and request deduplication](https://nextjs.org/docs/app/getting-started/fetching-data)
- [Cache Components migration](https://nextjs.org/docs/app/guides/migrating-to-cache-components)

## Companion app update

See [BFF and surfaces](bff-and-surfaces.md) for the implemented action/composition boundary. This guide describes production setup patterns (including Vitest and SSR hydration); the runnable demo retains its Node test runner, browser selection draft, latest server cart snapshots, and simulated orders. Do not infer an implemented model endpoint, production authentication, SSR cart restore or durable payment idempotency from these examples.
