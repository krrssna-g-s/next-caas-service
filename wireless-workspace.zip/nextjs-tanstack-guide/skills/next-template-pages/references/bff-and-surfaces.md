# Separate BFF, unrestricted composition and action-driven surfaces

Use this reference when implementing BFF APIs, business authoring, quick carts, mini carts, dialogs or flow-dependent navigation. The runnable companion is `wireless-bff/SETUP.md`; do not mistake demo conventions for production auth or persistence.

## Responsibilities

The Node BFF owns trusted calculations, action validation, page/surface composition and next-effect decisions. Next owns React implementations, rendering, interaction, accessibility and a central effect dispatcher. The composer configures published pages, drawer blocks and approved flow outcomes. No JSON contains executable code.

Every registered component may appear in any template or surface; do not add per-template component allowlists. Use stable instance IDs to allow repeated components with separate props/data. Validate identifiers, data shapes and slots. Template changes preserve blocks. A component can prompt for missing context locally without hiding unrelated blocks. Order/consent validation stays server-side even if an author removes transaction UI.

## Action protocol

Send a named action, validated user selections, journey context and idempotency key through a same-origin Next endpoint. Forward authenticated identity server-side; never trust browser cart IDs as authorization. The BFF performs the action, commits state, then returns a versioned cart snapshot plus an allowlisted effect: openSurface, navigate, or another explicitly supported outcome. Do not scatter customer/flow conditions across buttons.

A quick-cart response confirms the selected device and next steps. A mini-cart Details response shows a price breakdown. They share a drawer container and may reuse the same registered blocks, but their compositions and resolved data differ.

Keep the snapshot and effect consistent. Updating a plan/extra invalidates or updates related TanStack keys. A detail drawer uses the current cart revision. Prevent stale response races during identity/selection changes; production mutations require durable idempotency and optimistic concurrency, not only disabled buttons.

## Rendering and state

The drawer host is a Client Component for show/hide, focus, Escape, scroll locking and loading states. Page content may be server-rendered. A JSON action response renders through a client-safe registry; it cannot instantiate arbitrary React Server Components. A true RSC drawer requires a Next navigation/server rendering lifecycle, with server content passed into a client shell. SSR-capable Client Components are not equivalent to Server Components.

Use TanStack mutations for actions and query state for backend data; local state for which surface is open. Never store a server QueryClient at module scope. Use no-store for personalized requests. Persistent carts are application state, not a response cache. Authenticated SSR carts need an authorized request-time read and per-request hydration; browser sessionStorage is not available during SSR.

## Implementation checks

Cover different flow outcomes, failed mutation (no success drawer), missing selections, duplicate action attempts, cart ownership, stale revisions, repeated block independence, focus restoration/Escape, loading/error states, and summary/detail agreement. Preserve current repository test tooling; use Vitest/Testing Library for new production repo setup, plus production-browser verification for RSC and hydration.

## Current companion implementation boundaries

The demo uses `signal-cart` HttpOnly cookie → trusted local proxy header → file-backed latest snapshot. New line opens quick-cart; upgrade navigates to plan. Drawer surfaces/flow JSON are edited with the same draft/publish revision. Snapshot idempotency only remembers the latest action; orders remain simulated. There is no authenticated cart restore/SSR hydration or implemented AI concierge endpoint. Do not claim these are production-complete.
