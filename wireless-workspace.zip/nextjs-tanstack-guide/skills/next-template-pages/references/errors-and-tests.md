# Error handling and verification

## Error ownership

| Situation | Handling |
| --- | --- |
| Invalid user input | Field errors / typed mutation result; keep form draft |
| Unauthorized/expired session | Existing auth flow; cancel and clear stale user data |
| Forbidden resource | Controlled access-denied UX without resource disclosure |
| Truly missing route/content | notFound() / not-found.tsx |
| Optional server section unavailable | Typed result and local fallback; other sections continue |
| Unexpected route/server error | Nearest error.tsx |
| Root layout failure | global-error.tsx with its own html/body |
| Client component render exception | Local ErrorBoundary |
| Query failure | Query error state or deliberate throwOnError + reset boundary |
| Event-handler/mutation rejection | Explicit catch/useMutation onError; render recovery state |
| Version conflict (409) | Refetch latest snapshot; let user reconcile draft |
| Unknown payment outcome | Reconcile using backend idempotency/order status before retry |

Error boundaries do not automatically handle async event handlers, arbitrary promise rejections, or server-rendering exceptions in the way client render exceptions are handled. Client component boundaries are not a substitute for route/server error handling.

Never put cookies(), headers(), redirect(), notFound(), and all fetching inside one broad catch that converts every thrown value into a generic error. Framework control-flow signals must propagate. Catch known transport/domain errors around the narrow operation. Don't expose raw upstream JSON, stack traces, secrets, form values, or full transcripts in errors or logs.

## Route/global boundaries

Match the installed Next.js error prop contract. Releases differ: newer versions may expose `retry` or `unstable_retry`; older ones use `reset`. Read installed Next types/docs before choosing. For a version with reset, a conventional fallback is:

```tsx
'use client';
import { startTransition } from 'react';
import { useRouter } from 'next/navigation';

export default function ErrorPage({ error, reset }: {
  error: Error & { digest?: string }; reset: () => void;
}) {
  const router = useRouter();
  return <section role="alert">
    <h2>We couldn’t load this page.</h2>
    {error.digest && <p>Reference: {error.digest}</p>}
    <button onClick={() => startTransition(() => {
      router.refresh();
      reset();
    })}>Try again</button>
  </section>;
}
```

Where supported, use the framework's documented retry helper instead of recreating it. Never promise that reset alone re-fetches failed server data. Global-error replaces the root layout; its fallback needs html/body and must not depend on that failed layout's providers. It can offer a full reload as a recovery path.

## Component/query boundaries

```tsx
'use client';
import { ErrorBoundary } from 'react-error-boundary';
import { QueryErrorResetBoundary } from '@tanstack/react-query';

export function QuerySection({ children }: { children: React.ReactNode }) {
  return <QueryErrorResetBoundary>
    {({ reset }) => <ErrorBoundary
      onReset={reset}
      fallbackRender={({ resetErrorBoundary }) => <div role="alert">
        This section is unavailable.
        <button onClick={resetErrorBoundary}>Retry section</button>
      </div>}
    >{children}</ErrorBoundary>}
  </QueryErrorResetBoundary>;
}
```

The query must opt into throwing (for example throwOnError) for this boundary to catch its error. Otherwise handle isError inline. Preserve usable stale data with a refresh warning when appropriate; don't continue checkout with a stale, unverified quote. Unexpected render bugs may remain after retry; offer navigation/reload and report a sanitized event.

## Vitest

Example `vitest.config.mts` (adjust paths and merge existing config):

```ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import tsconfigPaths from 'vite-tsconfig-paths';
export default defineConfig({
  plugins: [react(), tsconfigPaths()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    include: ['src/**/*.{test,spec}.{ts,tsx}'],
    exclude: ['node_modules', '.next', 'tests/e2e/**'],
    clearMocks: true,
    coverage: { provider: 'v8', reporter: ['text', 'html'] },
  },
});
```

```ts
// src/test/setup.ts
import '@testing-library/jest-dom/vitest';
import { afterEach } from 'vitest';
import { cleanup } from '@testing-library/react';
afterEach(cleanup);
```

Use `// @vitest-environment node` for pure server/domain tests. Mock `server-only` only in the test runner when testing an isolated module; never alias it away in the application build. Mock auth/transport intentionally; don't let unit tests call live BFFs.

Create a **new QueryClient for every test** with query and mutation retries disabled. Wrap components with QueryClientProvider. Await UI updates and clear test clients. Use MSW for network contracts and responses; don't mock useQuery itself. Exercise behavior, not internal Query object layout.

Suggested merged scripts:

```json
{
  "test": "vitest",
  "test:run": "vitest run",
  "test:coverage": "vitest run --coverage",
  "typecheck": "tsc --noEmit",
  "test:e2e": "playwright test"
}
```

## E2E setup

```ts
// playwright.config.ts
import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/e2e',
  use: { baseURL: 'http://127.0.0.1:3100' },
  webServer: {
    command: 'npm run build && npm run start -- --port 3100',
    url: 'http://127.0.0.1:3100',
    reuseExistingServer: false,
    timeout: 180_000,
  },
});
```

Supply test BFF/auth configuration through the approved CI environment. Browser-only MSW cannot mock Server Component fetches; use a controlled BFF fixture process or test backend for those. Do not add unauthenticated production endpoints to make testing easier.

Vitest is appropriate for schemas, selectors, query-key factories, action contracts, local state transitions, and client components. Do not pretend jsdom unit rendering verifies asynchronous Server Components, Next's cache behavior, routing, or streaming. Use production-mode integration/E2E tests for these.

## Minimum meaningful test matrix

1. Manifest: unknown component/theme/version, invalid props, illegal slot, duplicate ID.
2. Query ownership: identical keys share data; user scope and resource changes use different keys.
3. SSR hydration: initial server/client values agree; no hydration warnings; refetch updates correctly.
4. Isolation: two authenticated users load the same path concurrently; no leaked HTML/RSC/query data.
5. Request cache: repeated same read within one render calls BFF once; a second request calls again. Use a counting fixture BFF, not only a mocked cache wrapper.
6. Parallel routes: each slot works after soft navigation and hard reload; shared reads deduplicate within their render scope.
7. Mutations: success, validation failure, 409 conflict, slow response, cancellation/account switch, and bounded retries.
8. Errors: route/global fallback, local render crash, optional server failure, stale-data warning, and recovery.
9. Production headers: no shared caching of personalized document, RSC, API, or authenticated error responses.
10. Concierge: malformed/incomplete UI stream, unregistered component/action, unauthorized entity, stale quote, failed tool, and required user confirmation.
11. Accessibility: keyboard, accessible names, focus after errors/dialogs, and restrained live-region announcements.

Use meaningful coverage targets for domain rules; don't chase coverage by testing generated markup. In CI run typecheck, Vitest, existing lint, build, and representative E2E journeys. Capture only sanitized logs/artifacts.

## Sources

- [Next.js errors](https://nextjs.org/docs/app/getting-started/error-handling)
- [Next.js Vitest limitations](https://nextjs.org/docs/app/guides/testing/vitest)
- [TanStack QueryErrorResetBoundary](https://tanstack.com/query/v5/docs/framework/react/reference/QueryErrorResetBoundary)

## Companion app update

See [BFF and surfaces](bff-and-surfaces.md) for the implemented action/composition boundary. This guide describes production setup patterns (including Vitest and SSR hydration); the runnable demo retains its Node test runner, browser selection draft, latest server cart snapshots, and simulated orders. Do not infer an implemented model endpoint, production authentication, SSR cart restore or durable payment idempotency from these examples.
