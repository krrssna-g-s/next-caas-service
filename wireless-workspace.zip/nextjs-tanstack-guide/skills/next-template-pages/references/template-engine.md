# Template engine and reusable UI

## Use a registered, unrestricted React composition engine

The engine is an application registry + runtime schema + React templates, not an HTML/JS interpreter. Do not eval strings, load arbitrary imports from JSON, or accept arbitrary JSX/CSS from a CMS or model.

```text
URL → authorized BFF → validated manifest + DTOs
    → server template/layout → registered blocks
    → focused client islands → shared TanStack Query provider
```

Example manifest:

```json
{
  "schemaVersion": 1,
  "template": "catalog",
  "theme": "default",
  "sections": [
    {"id":"intro","slot":"main","type":"hero","props":{"title":"Choose your next phone"}},
    {"id":"cart","slot":"aside","type":"cartSummary","props":{"cartId":"cart-123"}}
  ]
}
```

cartId is an identifier, not authority. The server must authorize the current principal's access. Do not include session tokens, prices that override backend calculation, or executable actions in the manifest.

## Schema and exhaustive renderer

```ts
import { z } from 'zod';
const common = { id: z.string().min(1), slot: z.enum(['main', 'aside']) };
const hero = z.object({ ...common, type: z.literal('hero'),
  props: z.object({ title: z.string().min(1).max(200) }).strict(),
}).strict();
const cart = z.object({ ...common, type: z.literal('cartSummary'),
  props: z.object({ cartId: z.string().min(1).max(100) }).strict(),
}).strict();
export const sectionSchema = z.discriminatedUnion('type', [hero, cart]);
export const pageSchema = z.object({
  schemaVersion: z.literal(1),
  template: z.enum(['catalog', 'checkout']),
  theme: z.enum(['default', 'compact']),
  sections: z.array(sectionSchema).max(40),
}).strict().superRefine((page, ctx) => {
  if (new Set(page.sections.map(s => s.id)).size !== page.sections.length) {
    ctx.addIssue({ code: 'custom', message: 'Section IDs must be unique' });
  }
});
export type Section = z.infer<typeof sectionSchema>;
```

```tsx
// Server-capable renderer; CartSummary itself may be a Client Component.
function SectionRenderer({ section, scopeKey }: {
  section: Section; scopeKey: string;
}) {
  switch (section.type) {
    case 'hero': return <Hero {...section.props} />;
    case 'cartSummary': return <CartSummary {...section.props} scopeKey={scopeKey} />;
    default: return assertNever(section);
  }
}
function assertNever(value: never): never {
  throw new Error('Unsupported section');
}
```

Implement the referenced components and types in the repo; this illustrates the contract, not a complete application file. Map templates to real layout components with named slots, and themes to design tokens. A template chooses structure, not arbitrary code. Register approved page-level blocks, not every atom.

All registered components may appear in all templates; validate supported slots and instance props, not template-specific component allowlists. Version the contract for rolling deployments. Default to failing a malformed mandatory manifest before rendering. If unknown optional sections can be skipped, define that policy explicitly and report it; never silently omit checkout totals, agreements, or required actions.

## Component hierarchy

| Layer | Responsibility | Fetching/state |
| --- | --- | --- |
| Atom | Button, text, icon, input | Props and minimal native interaction |
| Molecule | Field with label/error; price row | Controlled props; local UI where useful |
| Organism | Product card/grid, order summary | Prefer DTOs + callbacks for reuse |
| Feature container | Cart panel, quote selector | Query hooks, mutation lifecycle, domain actions |
| Template | Slots and layout | Composition, no hidden transaction rules |
| Page/route | Auth, data boundary, metadata | Server BFF loading, Suspense, hydration |

Use domain folders for feature logic. Atomic design is an organizational aid, not a requirement to wrap every HTML element or create long dependency chains. Avoid circular feature imports. Keep a server registry separate from the concierge's client-safe registry to avoid pulling server-only dependencies into browser bundles.

## New component workflow

1. Search for an existing component and extend its supported variant when appropriate.
2. Define typed props, accessible names, keyboard behavior, and design-token usage.
3. Keep display components independent of routing and global mutable stores where possible.
4. Use a feature container to obtain query data and bind typed callbacks.
5. Register only if the component should be selectable by page configuration or concierge output.
6. Add schema and contract tests for registration; interaction tests for behavior.
7. Document empty/loading/error/disabled states and required context.

## Routes

Use a scoped catch-all such as `app/experience/[[...slug]]/page.tsx` for configured pages; reserve account/auth and API routes as needed; cart and checkout can be composed pages too. Explicit routes can use the same renderer with a known page key. Specific routes take precedence; returning notFound from one does not fall back to a catch-all.

Place awaits of params/searchParams inside a component beneath Suspense. Validate path normalization, unknown slugs, redirects, allowed page IDs and access rights. Do not interpret a BFF fetch failure as a 404; unknown content and upstream failure are different cases. Auth errors must not reveal whether another user's resource exists.

## How to add a configured page

- Add a versioned page manifest in the BFF/CMS; static fixture changes require deployment if imported into the build.
- Add approved blocks to the schema and renderer only when absent.
- Define query keys and ownership for mutable blocks, using the existing provider.
- Load only required data and hydrate only that subtree's public queries.
- Keep metadata public unless deliberately supported as dynamic and non-sensitive.
- Verify build, known/unknown routes, loading, optional failure, and permission cases.

## Parallel routes and streaming

Each slot can have its own loading/error boundary and default.tsx where required by Next routing. Share imported request-memoized loaders and the server QueryClient only within the same render. Shared browser query keys deduplicate client work too. A slot must not assume another slot has run first or populated mutable state. Independent optional sections should not block the primary page.

For action-driven drawers, quick carts, mini carts and the separate Node BFF, use [bff-and-surfaces.md](bff-and-surfaces.md). The companion implementation uses manifest.blocks with id/component/slot/props/data; earlier sections/type examples above illustrate the general pattern, not its exact DTO.
