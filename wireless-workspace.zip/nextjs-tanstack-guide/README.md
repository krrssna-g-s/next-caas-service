# Next.js template engine and TanStack Query setup

Prepared November 17, 2026. For an existing Next.js App Router / TypeScript repository with React Compiler and Cache Components enabled. These are implementation instructions and reference snippets, not an installed or fully generated application.

## Decisions

- Keep TanStack Query. Do not introduce Redux or Zustand.
- Server data: request-scoped BFF reads and QueryClient; browser data: TanStack Query.
- Local UI: useState/useReducer; forms: React Hook Form + Zod; shareable state: URL.
- Request-level memoization is allowed, including the same reads used by parallel route slots in one render.
- Cross-request server DATA caching is forbidden. Static application assets and a data-free shell may still be prerendered/cached.
- Server and client consume the same validated, serializable DTOs and query keys. No server singleton stores.
- Only development builds expose a sanitized, read-only window inspector.
- The AI concierge consumes existing UI through a validated, client-safe registry and shares the page’s query provider.

## Read in order

1. [Setup and packages](skills/next-template-pages/references/setup.md)
2. [SSR, state, hydration, and caching](skills/next-template-pages/references/state-and-caching.md)
3. [Template engine and component hierarchy](skills/next-template-pages/references/template-engine.md)
4. [Errors and tests](skills/next-template-pages/references/errors-and-tests.md)
5. [AI concierge and shared UI](skills/next-template-pages/references/ai-concierge.md)
6. [Install the agent skill](INSTALL.md)

The reusable entry point is [SKILL.md](skills/next-template-pages/SKILL.md). [AGENTS.md](AGENTS.md) is a repository instruction snippet to merge into existing instructions, not overwrite them.

## Suggested first agent prompt

> Read the next-template-pages skill and its setup reference. Inspect this repo's installed Next.js and TanStack versions, app structure, auth, BFF client, providers, and existing tests. Preserve React Compiler and Cache Components. Keep TanStack Query; allow request-scoped deduplication but no cross-request server data cache. Implement a small vertical slice: a personalized template page, a reusable component, SSR hydration, a read-only development inspector, and Vitest coverage. Use existing auth and APIs; do not invent production authentication. Run relevant tests, typecheck, and a production build. Report any production isolation tests that could not run.

## Acceptance criteria

- Two authenticated users cannot receive each other's DTOs, query data, HTML, or RSC payloads.
- Identical reads within one server render deduplicate; subsequent requests read the source again.
- No dynamic/force-dynamic route configuration is introduced under Cache Components.
- Personalized reads are below Suspense and excluded from build-time data output.
- Hydration uses matching snapshots; client refetch, logout, account switch, and parallel slots work correctly.
- Client refetching does not leave a conflicting, stale Server Component total alongside it.
- Render errors, API errors, validation errors, missing pages, and mutation conflicts have distinct recovery paths.
- Payment/order mutations have backend idempotency before any automatic retry is considered.

## Compatibility and validation limits

Reference code targets TanStack Query v5 and Next.js 16 Cache Components. Verify APIs against the repository lockfile and any documentation bundled with its installed Next.js. Do not upgrade an existing TanStack installation merely to match an example. In particular, Next.js error-boundary retry APIs have changed across releases; the error guide uses a conservative refresh/reset pattern and explains version-specific alternatives.

The Markdown links and skill structure are checked. These snippets have not been compiled or integration-tested against your separate application; that repo and its authenticated BFF are not attached. The supplied test plan is part of the required implementation work.

## Updated companion implementation

The regenerated package includes a separate Node BFF, unrestricted component instances, new composed routes, BFF-resolved carousels, and action-driven quick-cart/mini-cart drawers. Read [BFF and surface architecture](skills/next-template-pages/references/bff-and-surfaces.md) and the sibling [BFF setup guide](../wireless-bff/SETUP.md). The skill folder remains self-contained when installed; the sibling BFF guide belongs to the full source bundle.
