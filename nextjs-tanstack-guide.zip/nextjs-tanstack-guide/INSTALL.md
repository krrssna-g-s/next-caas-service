# Install the instructions in an editor/agent

The skill is plain Markdown and supporting Markdown references. No extension, MCP server, or execution permission is installed by copying it. It does not automatically modify your application.

Copy the **whole** `skills/next-template-pages` folder, retaining `SKILL.md` and `references/`. Choose the native location for your agent, rather than creating duplicate copies with the same name in several auto-discovered locations.

| Environment | Project location / use |
| --- | --- |
| VS Code with GitHub Copilot | `.github/skills/next-template-pages/SKILL.md` |
| Cursor | `.cursor/skills/next-template-pages/SKILL.md` |
| Agents supporting the shared project skill location | `.agents/skills/next-template-pages/SKILL.md` |
| Devin | Commit the folder in the repo and explicitly instruct Devin to read its SKILL.md and linked references; use its current Skills/Knowledge installation UI if available |

VS Code support depends on the chosen agent/harness, not the editor alone. Copilot and other VS Code agents can have different discovery locations. In Cursor, invoke through its skills UI or `/next-template-pages` when available.

The current Devin native automatic-discovery location was not verified from accessible official documentation during preparation. Do not assume a `.devin` path or claim automatic loading. The portable fallback is reliable as an instruction: commit the files, attach/reference SKILL.md in the Devin task, and ask it to read the linked resources before editing. Confirm its task output identifies the loaded file. A repository AGENTS.md pointer is useful, but verify your Devin product/version actually loads it.

## Installation commands

Run from your repo root, replacing `/path/to/download` with the actual extracted folder:

```sh
# Choose ONE destination for this agent.
mkdir -p .github/skills
cp -R /path/to/download/skills/next-template-pages .github/skills/
```

For Cursor replace `.github/skills` with `.cursor/skills`. For a shared agent path use `.agents/skills`. Review existing destination files first; merge updates rather than overwrite local changes blindly. Avoid installation in a global home directory unless you intentionally want this architecture applied to other repos.

## Repository rules

Merge the supplied AGENTS.md text into the repo's existing instruction file and update the skill path to the chosen destination. For Copilot, you may also add a short pointer to `.github/copilot-instructions.md`. If your agent does not follow pointers automatically, explicitly attach the skill in the task. Do not duplicate the whole architecture guide into always-loaded rules.

## Verify discovery and behavior

Ask the agent:

> Read the next-template-pages skill. State the active cache policy, state ownership, and concierge component reuse rules before editing. Then implement only the requested vertical slice.

Expected: TanStack Query retained; server request deduplication allowed; no cross-request server data cache; React Compiler and Cache Components retained; runtime reads beneath Suspense; concierge uses approved shared components and validated actions.

Discovery alone does not guarantee correct execution. Review generated code, tests, provider lifetimes, cache directives, and auth boundaries.

## Example requests

- “Create `/offers/[id]` as a personalized template page with a reusable OfferCard organism and Vitest tests.”
- “Add a controlled AddressField molecule using our tokens and existing form validation.”
- “Add a `planComparison` block to both page and concierge registries using the same PlanCardView.”
- “Implement a concierge propose-plan interaction; require confirmation before mutation and invalidate the existing quote/cart keys.”
- “Audit this route for cross-request caching and hydration problems without changing its design.”

## Verified reference locations

- [VS Code agent skills](https://code.visualstudio.com/docs/agent-customization/agent-skills)
- [Cursor skills](https://prod.cursor.com/help/customization/skills)
