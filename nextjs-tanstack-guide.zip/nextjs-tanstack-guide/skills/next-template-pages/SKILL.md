---
name: next-template-pages
description: Create or extend Next.js App Router template pages, explicit routes, reusable UI components, AI-concierge UI, and TanStack Query integrations with request-scoped SSR state, hydration, error handling, and tests. Use for implementation in this architecture, not to replace an existing state stack or deploy an application.
---

# Next.js template pages

## Discover before editing

Read repository instructions, package.json, the lockfile, next.config, path aliases, auth/BFF integrations, provider placement, existing design system, and tests. Inspect installed-version documentation when available. Preserve the user's existing TanStack architecture, styles, and route conventions. Do not recreate the repo or blindly replace configuration.

Use [setup.md](references/setup.md) for a first installation. For pages/state/API work, read [state-and-caching.md](references/state-and-caching.md). For routes and UI composition, read [template-engine.md](references/template-engine.md). For AI concierge integration, read [ai-concierge.md](references/ai-concierge.md). For failures and verification, read [errors-and-tests.md](references/errors-and-tests.md).

## Non-negotiable project constraints

- Keep React Compiler and Cache Components enabled.
- No cross-request server data caching: no use cache data loaders, unstable_cache, positive revalidation TTLs, module-level server QueryClients/data Maps, external response caches, or ISR for user data.
- Request-scoped React cache() and TanStack deduplication are allowed. They are not durable or cross-navigation caches.
- Every authenticated BFF HTTP read uses no-store. Personalized API responses use private, no-store. Verify deployment headers and bypass shared CDN caching for personalized HTML/RSC/API responses.
- Runtime/auth/params-dependent reads occur under Suspense. Do not add dynamic='force-dynamic', fetchCache, or revalidate segment exports as a workaround for Cache Components errors.
- Server-only auth and credentials never enter query keys, props, dehydrated data, logs, debug output, or JSON configuration.
- Keep TanStack Query for server-owned data. No Redux/Zustand migration. Keep transient UI/form state out of query caches.
- Server QueryClients belong to a request; browser QueryClients belong to the current authenticated application scope. Clear/cancel old scoped work during logout/account changes.
- A component's hierarchy category does not determine its server/client boundary. Add use client only where runtime interactivity requires it.
- Treat payment, price, stock, consent, and eligibility as server-authoritative. UI configuration is not authorization.

## Implement a route or page

1. Decide explicit route versus the scoped template catch-all; reserve auth/API/cart/checkout paths.
2. Specify the public DTO and schema. Reuse query-key factories and pure selectors. Identify which data is mandatory and which can fail independently.
3. Add the manifest to the authorized BFF/CMS contract, or add an explicit page using the same renderer. A fixture is acceptable only when clearly identified as a fixture.
4. Load request data beneath Suspense, deduplicate with an imported request-scoped loader, and dehydrate only the queries needed by that subtree.
5. Keep server and browser query functions separate: server calls the BFF directly; browser calls a same-origin API/RPC endpoint. Never import server-only code into the client registry.
6. Add loading, empty, denied, not-found, expected-error, and unexpected-error behavior where applicable. Preserve framework redirect/notFound control flow.
7. Verify query ownership after mutations; avoid stale server-rendered aggregates beside client-refetched details.

## Implement an atom, molecule, organism, or feature

Search existing components first. Use semantic HTML and tokens. Atoms have no domain fetching; molecules compose small controls; organisms compose cohesive UI; feature containers own query hooks and workflow behavior. Do not register every atom in the JSON engine. Register only approved page-level blocks with validated props and stable IDs.

Add meaningful tests for interactions, accessibility, parsing, and failure behavior. A trivial presentational wrapper does not need tests that merely mirror its markup.

## Concierge work

Reuse existing presentational components through client-safe adapters. Keep the server page registry, client concierge registry, and server tool registry separate. Validate complete UI blocks before rendering; no executable JSX/HTML/actions from model text. Share the existing QueryClient and scoped keys. Revalidate all tool actions server-side and preserve explicit confirmation for consequential changes. Never feed window inspector output or an entire query cache into the model. Add tests for invalid blocks, authorization, scope changes, and mutation synchronization.

## Finish

Run relevant Vitest tests, typecheck, lint as established by the repo, and production build for server/route changes. Async RSC, streaming, two-user isolation, and hydration behavior need production-mode integration/E2E checks, not only mocked unit tests. Do not claim unrun tests passed. Summarize changed files, decisions, checks, and remaining integration requirements. Do not deploy or change unrelated infrastructure as part of this skill.
