# AI concierge using existing components

## Design goal

The page and concierge should reuse the same design system and feature logic. The concierge is another presentation surface, not a separate application or a second source of cart state.

```text
Authenticated user + current page
  → server concierge orchestrator
  → allowlisted read/action tools
  → validated tool results + structured UI blocks
  → client-safe UI registry
      → existing organism / molecule / atom
      → same TanStack Query provider and query keys
  → explicit user interaction
  → typed action dispatcher
  → authenticated BFF mutation
  → authoritative result + targeted query invalidation
```

Keep the model/vendor transport separate from UI contracts. Use the repo's existing AI SDK if one exists. Select additional SDK packages only after the model provider, streaming protocol, deployment runtime, and tool-calling requirements are known. This architecture does not require a particular AI vendor.

## Separate the registries

- **Page registry:** may include Server Components, BFF-loading wrappers, layouts, and client islands.
- **Concierge registry:** imports only components that are safe to render on the client. It must not import server-only auth, BFF modules, Server Components, or the entire page registry.
- **Tool registry:** server-side operations with input/output schemas and per-call authentication/authorization.
- **Action registry:** client adapters binding approved user gestures to typed, authenticated application operations.

Both UI registries can reuse the same presentational components. Keep data acquisition outside those shared components. For example, `PlanCardView` takes a Plan DTO and a callback; `PagePlanCard` and `ConciergePlanCard` load/bind the appropriate context and reuse that view.

Do not promote every atom to a model-callable UI type. Prefer task-level blocks such as ProductCard, PlanComparison, CartSummary, AddressForm, or ConfirmationRequest. Atoms and molecules compose these blocks internally. Where direct atom/molecule output is useful, expose a deliberately limited schema and safe variants.

## Example UI block contract

```ts
import { z } from 'zod';
const id = z.string().min(1).max(100);
const action = z.discriminatedUnion('type', [
  z.object({ type: z.literal('viewProduct'), productId: id }).strict(),
  z.object({ type: z.literal('proposePlan'), planId: id }).strict(),
]);
export const conciergeBlockSchema = z.discriminatedUnion('type', [
  z.object({ id, type: z.literal('text'), text: z.string().max(4000) }).strict(),
  z.object({ id, type: z.literal('productCard'), productId: id }).strict(),
  z.object({ id, type: z.literal('planComparison'),
    planIds: z.array(id).min(1).max(3) }).strict(),
  z.object({ id, type: z.literal('cartSummary'), cartId: id }).strict(),
  z.object({ id, type: z.literal('actionButton'),
    label: z.string().min(1).max(80), action }).strict(),
]);
export const conciergeMessageSchema = z.object({
  version: z.literal(1),
  messageId: id,
  blocks: z.array(conciergeBlockSchema).max(12),
}).strict();
```

Add uniqueness checks for block IDs and a maximum total message size. References to product/plan/cart IDs must resolve through authorized server data. Do not render model-invented prices, balances, availability, or offer eligibility as authoritative facts. Reject arbitrary URLs, import paths, HTML, event-handler strings, scripts, CSS, and executable expressions.

## Reuse existing components

```tsx
'use client';
// Illustrative adapter; use your existing query keys, hooks and components.
function ConciergeProductCard({ productId, scopeKey }: {
  productId: string; scopeKey: string;
}) {
  const query = useProductQuery(scopeKey, productId);
  if (query.isPending) return <ProductCardSkeleton />;
  if (query.isError) return <InlineRetry onRetry={() => query.refetch()} />;
  return <ProductCardView
    product={query.data}
    onSelect={() => openProductRoute(query.data.id)}
  />;
}
```

`useProductQuery`, `ProductCardView`, and route helpers are project-owned integration points. No new provider should be created inside a card. A portal opened from within the app's provider subtree retains React context; a separately mounted React root does not. If the concierge is an iframe/microfrontend, use an explicit authenticated message/API contract instead of attempting to share React context or using window.__APP_STATE__.

Supply presentation variants such as `surface="concierge"` or `density="compact"` when needed. Do not fork business logic or duplicate components purely because the surface is conversational. Document required contexts so a molecule does not silently assume it lives inside a particular form/provider.

## Tools and user actions

Read tools may retrieve authorized product, plan, cart, and eligibility DTOs. Write tools must enforce the same domain rules as the normal UI. The model is not a trusted principal and cannot choose a user ID to impersonate.

For actions that change a cart or selected plan, present the proposed change with current authoritative price and scope, then require the applicable user confirmation. Revalidate price/revision/eligibility when executing, even if the conversational card is recent. Purchases, payment authorization, financing, porting, and agreement acceptance must use the actual application's explicit confirmation process; the model cannot infer consent from a conversation or tick required agreements automatically.

Tool calls must validate input, authenticate the current request, authorize the entity, enforce rate limits and idempotency where appropriate, and return a bounded public DTO. Do not accept a tool name or destination URL from arbitrary generated text. Agent instructions and retrieved content must not override these controls.

After a successful mutation, update/invalidate the same scoped cart/quote query keys used by the page. Refresh RSC-owned output if needed. Do not optimistically announce an order is placed before authoritative success. On an uncertain result, reconcile by idempotency key/order status rather than retrying blindly.

## State and conversation lifetime

- Cart, products, plans: existing TanStack Query keys.
- Open/closed concierge panel: local UI state.
- Composer draft: local state or React Hook Form.
- Streaming messages/tool progress: a scoped conversation reducer or the existing SDK's conversation state.
- Persisted conversation: explicit backend storage, if required, scoped to the user/tenant. It is storage, not a shared response cache.
- Sensitive identifiers and credentials: server only; provide the model only the minimum authorized context.

Do not dump QueryClient state, form contents, or window inspection output into the model prompt. Build an allowlisted server context DTO. Clear or switch conversation scope on logout/account change and reject old-scope streaming events/results.

## Streaming contract

Separate text deltas, tool status, validated UI blocks, and errors. Render pending/loading UI for incomplete blocks; only instantiate a registered component when a complete block has passed schema validation. Do not JSON.parse arbitrary partial token chunks and render them as props.

Give messages/blocks stable IDs and define update ordering. Support abort on navigation, account switch, or user cancellation. Ensure reconnection/retry cannot duplicate mutations. Never replay a write tool merely because the UI stream reconnected. A model's suggested priority or tool name is not authorization.

Server render the page and concierge shell; load personalized conversation data at request time under Suspense when needed. The model stream starts from an authenticated request and must not be cached across requests. Protect its response with private, no-store and verify any proxy streaming/buffering behavior.

## Error isolation and accessibility

Wrap each rich block in an appropriate client render boundary plus query failure UI. An invalid or unsupported block should show a neutral fallback and leave the rest of the conversation usable. Preserve server errors as structured, sanitized events. Model timeout, tool denial, stale quote, and component render failure need different messages.

Maintain focus when opening/closing the concierge. Use accessible dialog/region labeling, keyboard navigation, and controlled live announcements for streaming; don't announce every token. Forms need their original labels/errors even in compact chat cards. A large comparison or checkout form can open the existing full-page UI instead of squeezing it into a chat bubble.

## Tests

- One organism renders on both page and concierge with the same DTO and correct accessible behavior.
- Page and concierge observing the same key share query results; a mutation updates both.
- Invalid types, props, actions, entity IDs, oversized messages, and partial JSON do not render unsafe UI.
- Tool requests cannot access another user's cart, even if the model provides its ID.
- A suggested purchase cannot execute without the application's required user confirmation.
- A stale quote is rejected/reconciled; duplicate stream events do not duplicate actions.
- Account switch aborts old streams and clears scoped state; late responses cannot populate the new session.
- Model/tool failure affects the relevant block only, with a usable retry/fallback.
